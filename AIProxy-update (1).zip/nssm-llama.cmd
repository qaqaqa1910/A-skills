@echo off
rem Параметры llama-server для CPU Xeon 6 vCPU / 32 ГБ RAM / Qwen2.5-Coder-7B Q4_K_M.
rem Замените llama-server на имя вашей службы NSSM, если оно другое. Запускать от администратора.
nssm set llama-server AppParameters -m O:\AI\LLM\Meta\Llama-3.1\qwen2.5-coder-7b-instruct-q4_k_m.gguf --alias qwen-coder -t 6 -tb 6 -c 65536 -np 2 --cache-reuse 256 --temp 0.2 --repeat-penalty 1.05 -n 3072 --host 127.0.0.1 --port 8080
nssm restart llama-server
