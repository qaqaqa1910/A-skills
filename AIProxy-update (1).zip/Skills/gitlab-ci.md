---
id: gitlab-ci
group: devops
description: Пайплайны GitLab CI/CD
triggers: gitlab, .gitlab-ci, пайплайн, pipeline, ci/cd, cicd, stages, runner, раннер, artifacts, артефакт, merge request
temperature: 0.1
max_tokens: 2500
---
GitLab CI/CD. Output a valid .gitlab-ci.yml fragment in one yaml block.
Always set stages, a stage and script for every job. Use rules: (not only/except), needs: for DAG, artifacts: with expire_in, cache: with key and paths.
Secrets only via masked CI/CD variables ($VAR), never in YAML. 2-space indent, no tabs. Use extends/anchors/include to avoid duplication.
When changing an existing pipeline: change only the requested jobs, keep the rest identical, show only the changed jobs.
Use only keywords you are sure exist; otherwise write "Не подтверждено". Windows runner: shell powershell, quote paths.
End with: validate via /check (GitLab CI Lint).
