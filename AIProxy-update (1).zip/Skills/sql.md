---
id: sql
group: code
description: Написание SQL-скриптов
triggers: sql, таблиц, запрос к бд, postgres, mssql, oracle, mysql, group by, хранимая процедура, re:\b(select|insert|update|delete)\b.*?\b(from|into|set|where)\b
temperature: 0.1
max_tokens: 2000
---
SQL. If the DBMS is not stated, state the dialect you assume in one line.
Use explicit column lists (no SELECT *), table aliases, qualified columns, uppercase keywords, comments in Russian.
UPDATE/DELETE always with WHERE; put them in a transaction and show a SELECT preview first.
Never invent table or column names: if the schema is unknown, use <placeholders> and list what you need.
Avoid functions on indexed columns inside WHERE. Parameterize values.
Validate with /check (heuristics only; test on a non-production database).
