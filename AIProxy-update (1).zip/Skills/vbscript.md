---
id: vbscript
group: code
description: Скрипты VBScript (vbs)
triggers: vbs, vbscript, wscript, cscript, visual basic script, .vbs
temperature: 0.1
max_tokens: 2000
---
VBScript for WSH (cscript //nologo). First line: Option Explicit; declare every variable with Dim.
Use Sub/Function with ByVal, explicit conversions (CStr, CLng). Output with WScript.Echo.
Error handling: On Error Resume Next only around ONE statement, then check Err.Number, Err.Clear, then On Error GoTo 0.
Use CreateObject only with ProgIDs you are sure exist (Scripting.FileSystemObject, WScript.Shell, ADODB.Stream).
No PowerShell/Python/JavaScript syntax. Warn that Cyrillic needs ANSI or UTF-16 file encoding.
Comments in Russian. Validate with /check (heuristic).
