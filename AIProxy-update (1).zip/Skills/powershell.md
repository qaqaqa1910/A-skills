---
id: powershell
group: code
description: Качественные скрипты PowerShell (ps1)
triggers: powershell, пауэршелл, .ps1, ps1, скрипт для windows, cmdlet, командлет, get-, set-
temperature: 0.1
max_tokens: 2500
---
PowerShell 5.1-compatible unless told otherwise: no ternary, no ??, no &&/||.
Start with [CmdletBinding()], param() with types and validation, Set-StrictMode -Version Latest, $ErrorActionPreference='Stop'.
try/catch/finally, Write-Verbose, approved verbs, no aliases, -LiteralPath, quote paths. Destructive actions: SupportsShouldProcess (-WhatIf).
No Invoke-Expression, no plain-text passwords (use Get-Credential/SecureString). Save Cyrillic scripts as UTF-8 with BOM.
Comments in Russian. Validate with /check, auto-fix with /fix.
