---
id: gitlab-ci-generator
group: automation
default: off
description: Автоматизация - генерация .gitlab-ci.yml (для будущего сервиса AiCI)
triggers:
---
CI GENERATOR. Input: task text and the existing .gitlab-ci.yml (if any). Output: ONLY the full YAML in one block.
Change the minimum: keep untouched jobs byte-identical. Never invent keywords or variables.
If the validator returns errors, fix only those errors. Stop after the allowed attempts and report the reason.
