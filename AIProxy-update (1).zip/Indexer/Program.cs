// =====================================================================
//  Indexer — индексация документов O:\AI\Knowledge\Documents для поиска в AIProxy.
//  Что улучшено по сравнению с прежней версией:
//   • нарезка по РАЗДЕЛАМ документа (заголовки Word/MD/HTML) с «хлебными крошками» «Документ > Раздел > Подраздел»;
//   • таблицы сохраняются как строки Markdown, у длинных таблиц шапка повторяется в каждом фрагменте;
//   • инкрементальная индексация: неизменённые файлы берутся из кэша (Index\cache), полная пересборка — ключ --full;
//   • исправлена квадратичная медленная нумерация фрагментов;
//   • команда search использует тот же поиск (BM25 + стеммер + проверка уверенности), что и AIProxy.
//  Использование:  Indexer index [--full]   |   Indexer search "запрос"
//  В проект нужно положить общие файлы Chunker.cs и Knowledge.cs (те же, что в AIProxy).
// =====================================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml.Linq;

internal class Program
{
    private static readonly string KnowledgeRoot = @"O:\AI\Knowledge";
    private static readonly string DocumentsDir = @"O:\AI\Knowledge\Documents";
    private static readonly string IndexDir = @"O:\AI\Knowledge\Index";
    private static readonly string LogsDir = @"O:\AI\Knowledge\Logs";
    private static readonly string TempDir = @"O:\AI\Knowledge\Temp";
    private static readonly string IndexFile = @"O:\AI\Knowledge\Index\documents.jsonl";
    private static readonly string CacheDir = @"O:\AI\Knowledge\Index\cache";
    private static readonly string LibreOfficePath = @"C:\Program Files\LibreOffice\program\soffice.exe";

    // Версия формата кэша: при изменении правил нарезки увеличьте — кэш пересоберётся сам.
    private const int SchemaVersion = 2;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    private static int Main(string[] args)
    {
        try
        {
            Directory.CreateDirectory(KnowledgeRoot);
            Directory.CreateDirectory(DocumentsDir);
            Directory.CreateDirectory(IndexDir);
            Directory.CreateDirectory(CacheDir);
            Directory.CreateDirectory(LogsDir);
            Directory.CreateDirectory(TempDir);

            if (args.Length > 0 && args[0].Equals("search", StringComparison.OrdinalIgnoreCase))
            {
                string query = string.Join(" ", args.Skip(1)).Trim();
                if (string.IsNullOrWhiteSpace(query))
                {
                    Console.WriteLine("Укажите запрос: Indexer search \"текст запроса\"");
                    return 1;
                }
                Search(query);
                return 0;
            }

            if (args.Length > 0 && !args[0].Equals("index", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Использование:");
                Console.WriteLine("  Indexer index [--full]");
                Console.WriteLine("  Indexer search \"ваш запрос\"");
                return 1;
            }

            BuildIndex(args.Any(a => a.Equals("--full", StringComparison.OrdinalIgnoreCase)));
            return 0;
        }
        catch (Exception ex)
        {
            Log("FATAL " + ex);
            Console.Error.WriteLine("Ошибка: " + ex.Message);
            return 1;
        }
    }

    // ------------------------------------------------------------------ индексация
    private static void BuildIndex(bool full)
    {
        string[] supported = { ".txt", ".md", ".html", ".htm", ".docx", ".pdf", ".doc" };
        int processed = 0, reused = 0, skipped = 0, chunkCount = 0;
        var keep = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        Console.WriteLine("Индексация документов" + (full ? " (полная)" : " (инкрементальная)") + "...");
        Console.WriteLine("Источник: " + DocumentsDir);

        string tmpIndex = IndexFile + ".tmp";
        using (var writer = new StreamWriter(tmpIndex, false, new UTF8Encoding(false)))
        {
            foreach (string file in Directory.EnumerateFiles(DocumentsDir, "*", SearchOption.AllDirectories)
                         .OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
            {
                string ext = Path.GetExtension(file).ToLowerInvariant();
                if (!supported.Contains(ext)) continue;

                string rel = Path.GetRelativePath(DocumentsDir, file);
                string cacheFile = Path.Combine(CacheDir, Hash(rel) + ".jsonl");
                keep.Add(cacheFile);
                var fi = new FileInfo(file);
                string meta = JsonSerializer.Serialize(new { v = SchemaVersion, mtime = fi.LastWriteTimeUtc.Ticks, size = fi.Length });

                try
                {
                    // 1. Неизменённый файл — берём готовые фрагменты из кэша
                    if (!full && File.Exists(cacheFile))
                    {
                        var lines = File.ReadAllLines(cacheFile, Encoding.UTF8);
                        if (lines.Length > 0 && lines[0] == meta)
                        {
                            foreach (string l in lines.Skip(1)) writer.WriteLine(l);
                            chunkCount += lines.Length - 1;
                            reused++;
                            continue;
                        }
                    }

                    // 2. Новый или изменённый файл — разбираем заново
                    string text = NormalizeText(ExtractText(file, ext));
                    if (string.IsNullOrWhiteSpace(text))
                    {
                        skipped++;
                        Log("SKIP пустой текст: " + file);
                        Console.WriteLine("ПУСТО: " + Path.GetFileName(file));
                        continue;
                    }

                    string title = Path.GetFileNameWithoutExtension(file);
                    var pieces = Chunker.Split(title, text);
                    var outLines = new List<string> { meta };
                    int part = 0;
                    foreach (var p in pieces)
                    {
                        outLines.Add(JsonSerializer.Serialize(
                            new KnowledgeChunk { Source = rel, Part = part++, Heading = p.Heading, Text = p.Text }, JsonOptions));
                    }
                    File.WriteAllLines(cacheFile, outLines, new UTF8Encoding(false));
                    foreach (string l in outLines.Skip(1)) writer.WriteLine(l);
                    chunkCount += pieces.Count;
                    processed++;
                    Log("OK " + file + " chunks=" + pieces.Count);
                    Console.WriteLine("OK: " + Path.GetFileName(file) + " — фрагментов: " + pieces.Count);
                }
                catch (Exception ex)
                {
                    skipped++;
                    Log("ERROR " + file + ": " + ex);
                    Console.WriteLine("ОШИБКА: " + Path.GetFileName(file) + " — " + ex.Message);
                }
            }
        }
        File.Move(tmpIndex, IndexFile, true);

        // Удаляем кэш документов, которых больше нет
        foreach (string c in Directory.GetFiles(CacheDir, "*.jsonl"))
            if (!keep.Contains(c)) { try { File.Delete(c); } catch { } }

        Log($"INDEX COMPLETE new={processed} cached={reused} skipped={skipped} chunks={chunkCount}");
        Console.WriteLine();
        Console.WriteLine("Индексация завершена.");
        Console.WriteLine("Разобрано заново: " + processed + ", из кэша: " + reused + ", пропущено/с ошибками: " + skipped);
        Console.WriteLine("Всего фрагментов: " + chunkCount);
        Console.WriteLine("Индекс: " + IndexFile);
    }

    private static string Hash(string s)
    {
        using var sha = SHA1.Create();
        return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(s.ToLowerInvariant())));
    }

    // ------------------------------------------------------------------ извлечение текста
    private static string ExtractText(string file, string extension)
    {
        switch (extension)
        {
            case ".txt":
            case ".md":
                return File.ReadAllText(file, Encoding.UTF8);
            case ".html":
            case ".htm":
                return HtmlToStructured(File.ReadAllText(file, Encoding.UTF8));
            case ".docx":
                return ExtractDocx(file);
            case ".pdf":
                return HtmlToStructured(ConvertWithLibreOffice(file, "html"));
            case ".doc":
                return ConvertWithLibreOffice(file, "txt");
            default:
                throw new NotSupportedException("Формат " + extension + " не поддерживается.");
        }
    }

    private static readonly XNamespace W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

    private static string ExtractDocx(string file)
    {
        using ZipArchive archive = ZipFile.OpenRead(file);
        ZipArchiveEntry? entry = archive.GetEntry("word/document.xml");
        if (entry == null) throw new InvalidDataException("В DOCX не найден word/document.xml.");

        // имена стилей: styleId -> name (чтобы распознать «Заголовок 1»)
        var styleNames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        ZipArchiveEntry? se = archive.GetEntry("word/styles.xml");
        if (se != null)
        {
            using Stream ss = se.Open();
            foreach (XElement st in XDocument.Load(ss).Descendants(W + "style"))
            {
                string? id = st.Attribute(W + "styleId")?.Value;
                string? name = st.Element(W + "name")?.Attribute(W + "val")?.Value;
                if (id != null && name != null) styleNames[id] = name;
            }
        }

        using Stream stream = entry.Open();
        XDocument xml = XDocument.Load(stream);
        var sb = new StringBuilder();
        XElement? body = xml.Root?.Element(W + "body");
        if (body != null) Walk(body.Elements(), styleNames, sb);
        return sb.ToString();
    }

    private static void Walk(IEnumerable<XElement> elements, Dictionary<string, string> styles, StringBuilder sb)
    {
        foreach (XElement el in elements)
        {
            if (el.Name == W + "p") AppendParagraph(el, styles, sb);
            else if (el.Name == W + "tbl") AppendTable(el, sb);
            else if (el.Name == W + "sdt") Walk(el.Element(W + "sdtContent")?.Elements() ?? Enumerable.Empty<XElement>(), styles, sb);
        }
    }

    private static string ParagraphText(XElement p)
    {
        var line = new StringBuilder();
        foreach (XNode node in p.DescendantNodes())
        {
            if (node is not XElement e) continue;
            if (e.Name == W + "t") line.Append(e.Value);
            else if (e.Name == W + "tab") line.Append('\t');
            else if (e.Name == W + "br" || e.Name == W + "cr") line.Append(' ');
        }
        return line.ToString().Trim();
    }

    private static void AppendParagraph(XElement p, Dictionary<string, string> styles, StringBuilder sb)
    {
        string text = ParagraphText(p);
        if (text.Length == 0) return;

        XElement? ppr = p.Element(W + "pPr");
        int level = 0;
        string? styleId = ppr?.Element(W + "pStyle")?.Attribute(W + "val")?.Value;
        if (styleId != null)
        {
            string name = styles.TryGetValue(styleId, out string? n) ? n : styleId;
            var m = Regex.Match(name, @"^(?:heading|заголовок)\s*(\d)", RegexOptions.IgnoreCase);
            if (m.Success) level = int.Parse(m.Groups[1].Value);
            else if (Regex.IsMatch(name, @"^(title|название)$", RegexOptions.IgnoreCase)) level = 1;
        }
        if (level == 0 && int.TryParse(ppr?.Element(W + "outlineLvl")?.Attribute(W + "val")?.Value, out int ol) && ol < 9) level = ol + 1;

        if (level > 0 && text.Length <= 200)
            sb.Append("\n\n").Append(new string('#', Math.Min(level, 6))).Append(' ').Append(text).Append("\n\n");
        else if (ppr?.Element(W + "numPr") != null)
            sb.Append("- ").Append(text).Append('\n');
        else
            sb.Append(text).Append("\n\n");
    }

    private static void AppendTable(XElement tbl, StringBuilder sb)
    {
        sb.Append("\n\n");
        bool first = true;
        foreach (XElement tr in tbl.Elements(W + "tr"))
        {
            var cells = tr.Elements(W + "tc")
                .Select(tc => string.Join(" ", tc.Elements(W + "p").Select(ParagraphText).Where(t => t.Length > 0)).Replace("|", "/"))
                .ToList();
            if (cells.Count == 0) continue;
            sb.Append("| ").Append(string.Join(" | ", cells)).Append(" |\n");
            if (first) { sb.Append("|").Append(string.Concat(cells.Select(_ => " --- |"))).Append('\n'); first = false; }
        }
        sb.Append("\n\n");
    }

    private static string ConvertWithLibreOffice(string sourceFile, string outputFormat)
    {
        if (!File.Exists(LibreOfficePath))
            throw new FileNotFoundException("Не найден LibreOffice.", LibreOfficePath);

        string workDir = Path.Combine(TempDir, Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(workDir);
        try
        {
            // Короткое ASCII-имя помогает избежать проблем с кириллицей в именах файлов.
            string inputExtension = Path.GetExtension(sourceFile).ToLowerInvariant();
            string inputFile = Path.Combine(workDir, "input" + inputExtension);
            File.Copy(sourceFile, inputFile, true);

            string filter = outputFormat == "txt" ? "txt:Text (encoded):UTF8" : "html";
            var startInfo = new ProcessStartInfo
            {
                FileName = LibreOfficePath, WorkingDirectory = workDir, UseShellExecute = false,
                RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true
            };
            startInfo.ArgumentList.Add("--headless");
            startInfo.ArgumentList.Add("--convert-to");
            startInfo.ArgumentList.Add(filter);
            startInfo.ArgumentList.Add("--outdir");
            startInfo.ArgumentList.Add(workDir);
            startInfo.ArgumentList.Add(inputFile);

            using Process process = new() { StartInfo = startInfo };
            process.Start();
            string stdout = process.StandardOutput.ReadToEnd();
            string stderr = process.StandardError.ReadToEnd();
            if (!process.WaitForExit(120000))
            {
                try { process.Kill(true); } catch { }
                throw new TimeoutException("LibreOffice не завершил конвертацию за 120 секунд: " + sourceFile);
            }

            string outputFile = Path.Combine(workDir, "input" + (outputFormat == "txt" ? ".txt" : ".html"));
            if (process.ExitCode != 0 || !File.Exists(outputFile))
                throw new InvalidOperationException("LibreOffice не создал выходной файл. Код: " + process.ExitCode + ". Вывод: " + stdout + " " + stderr);

            return File.ReadAllText(outputFile, Encoding.UTF8);
        }
        finally
        {
            try { if (Directory.Exists(workDir)) Directory.Delete(workDir, true); }
            catch (Exception ex) { Log("WARN не удалось удалить временную папку " + workDir + ": " + ex.Message); }
        }
    }

    // HTML -> текст со структурой: заголовки (#), списки (-), таблицы (| a | b |)
    private static string HtmlToStructured(string html)
    {
        if (string.IsNullOrEmpty(html)) return "";
        html = Regex.Replace(html, @"<(script|style|noscript|svg)\b[^>]*>.*?</\1\s*>", " ", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        html = Regex.Replace(html, @"<h([1-6])\b[^>]*>", m => "\n\n" + new string('#', int.Parse(m.Groups[1].Value)) + " ", RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"<tr\b[^>]*>", "\n| ", RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"<li\b[^>]*>", "\n- ", RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"</t[dh]\s*>", " | ", RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"<(br|/p|/div|/tr|/h[1-6]|/li|/table|/section|/article|/ul|/ol)\b[^>]*>", "\n", RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"<!--.*?-->", " ", RegexOptions.Singleline);
        html = Regex.Replace(html, @"<[^>]+>", "");
        return System.Net.WebUtility.HtmlDecode(html);
    }

    private static string NormalizeText(string text)
    {
        text = text.Replace("\0", " ").Replace("\r\n", "\n").Replace('\r', '\n');
        text = Regex.Replace(text, @"[ \t\f\v\u00A0]+", " ");
        text = Regex.Replace(text, @" *\n *", "\n");
        text = Regex.Replace(text, @"\n{3,}", "\n\n");
        return text.Trim();
    }

    // ------------------------------------------------------------------ поиск (тот же, что в AIProxy)
    private static void Search(string query)
    {
        if (!File.Exists(IndexFile))
        {
            Console.WriteLine("Индекс не найден. Сначала выполните: Indexer index");
            return;
        }
        FindResult r = Knowledge.Search(query, new[] { IndexFile }, 5, 0.5);
        Console.WriteLine("Запрос: " + query);
        Console.WriteLine();
        if (!r.Confident)
        {
            Console.WriteLine(Knowledge.NotFoundText(query, r));
            return;
        }
        if (r.Ambiguous) Console.WriteLine("(!) Несколько документов подходят одинаково хорошо — различайте источники.\n");
        foreach (KnowledgeChunk c in r.Chunks)
        {
            Console.WriteLine("Источник: " + c.Source + " | Фрагмент: " + (c.Part + 1));
            Console.WriteLine(c.Text);
            Console.WriteLine(new string('-', 70));
        }
    }

    private static void Log(string message)
    {
        try
        {
            string logFile = Path.Combine(LogsDir, $"indexer-{DateTime.Now:yyyy-MM-dd}.log");
            File.AppendAllText(logFile, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}", new UTF8Encoding(false));
        }
        catch
        {
            // Ошибка записи журнала не должна останавливать индексацию.
        }
    }
}
