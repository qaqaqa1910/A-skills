# -*- coding: utf-8 -*-
# Проверка Python-кода без выполнения: синтаксис + частые ошибки. Только стандартная библиотека.
import ast
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

path = sys.argv[1]
with open(path, encoding="utf-8") as f:
    src = f.read()

try:
    tree = ast.parse(src, filename="code.py")
except SyntaxError as e:
    print("ERR: строка %s, позиция %s: %s" % (e.lineno, e.offset, e.msg))
    sys.exit(0)

for n in ast.walk(tree):
    if isinstance(n, ast.ExceptHandler) and n.type is None:
        print("WARN: строка %d: голый except — укажите тип исключения" % n.lineno)
    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
        defaults = list(n.args.defaults) + [d for d in n.args.kw_defaults if d is not None]
        for d in defaults:
            if isinstance(d, (ast.List, ast.Dict, ast.Set)):
                print("WARN: строка %d: изменяемое значение аргумента по умолчанию" % n.lineno)
    if isinstance(n, ast.Call):
        name = getattr(n.func, "id", getattr(n.func, "attr", ""))
        if name in ("eval", "exec"):
            print("WARN: строка %d: использование %s небезопасно" % (n.lineno, name))
        for k in n.keywords:
            if k.arg == "shell" and isinstance(k.value, ast.Constant) and k.value.value is True:
                print("WARN: строка %d: shell=True небезопасен при пользовательском вводе" % n.lineno)
print("INFO: синтаксис Python корректен")
