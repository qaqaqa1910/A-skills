﻿# Проверка синтаксиса PowerShell без выполнения кода (встроенный парсер). Вызывается из AIProxy (/check).
param([Parameter(Mandatory = $true)][string]$Path)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$tokens = $null
$errors = $null
[void][System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$errors)
foreach ($e in $errors) {
    'ERR: строка {0}, позиция {1}: {2}' -f $e.Extent.StartLineNumber, $e.Extent.StartColumnNumber, $e.Message
}
if (Get-Module -ListAvailable -Name PSScriptAnalyzer) {
    Invoke-ScriptAnalyzer -Path $Path -Severity Error, Warning | ForEach-Object {
        'WARN: строка {0}: {1} ({2})' -f $_.Line, $_.Message, $_.RuleName
    }
} else {
    'INFO: PSScriptAnalyzer не установлен, проверен только синтаксис'
}
