// =====================================================================
//  Skills.cs — навыки («скиллы») модели.
//  Навык = файл *.md в папке навыков: заголовок (frontmatter) + короткая инструкция на английском.
//  В промпт попадают только обязательные навыки (always) и 1–2 подходящих по ключевым словам.
//  Включение/выключение: команды чата /skills, /skill on|off <id|группа>, состояние в skills.state.json.
//  Новый навык = положить новый .md в папку (подхватывается без перезапуска).
// =====================================================================
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

public sealed class Skill
{
    public string Id = "", Group = "general", Description = "", Text = "", File = "";
    public string[] Triggers = Array.Empty<string>();
    public bool Always;                 // обязательный навык: всегда в промпте, не отключается из чата
    public bool DefaultOn = true;       // состояние по умолчанию
    public double? Temperature;         // температура генерации для навыка
    public int? MaxTokens;              // лимит ответа для навыка
    public int EstTokens => (int)(Text.Length / 3.5);
}

public sealed class SkillSelection
{
    public string Block = "";
    public List<string> Ids = new List<string>();
    public double? Temperature;
    public int? MaxTokens;
}

public sealed class SkillEngine
{
    readonly string _dir;
    readonly int _maxAuto;
    readonly object _lock = new object();
    List<Skill> _skills = new List<Skill>();
    Dictionary<string, bool> _state = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
    string _sig = "";

    string StateFile => Path.Combine(_dir, "skills.state.json");

    public SkillEngine(string dir, int maxAuto)
    {
        _dir = dir;
        _maxAuto = Math.Max(0, maxAuto);
        Directory.CreateDirectory(_dir);
        Reload();
    }

    string Signature()
    {
        var files = Directory.Exists(_dir) ? Directory.GetFiles(_dir, "*.md").Concat(new[] { StateFile }).Where(File.Exists) : Enumerable.Empty<string>();
        return string.Join("|", files.OrderBy(f => f).Select(f => Path.GetFileName(f) + ":" + File.GetLastWriteTimeUtc(f).Ticks));
    }

    void Refresh()
    {
        string sig = Signature();
        if (sig != _sig) Reload();
    }

    void Reload()
    {
        lock (_lock)
        {
            var list = new List<Skill>();
            foreach (string f in Directory.GetFiles(_dir, "*.md").OrderBy(x => x))
            {
                try { var s = Parse(f); if (s != null) list.Add(s); }
                catch (Exception ex) { Console.Error.WriteLine("[Skills] " + f + ": " + ex.Message); }
            }
            _skills = list;
            _state = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
            try
            {
                if (File.Exists(StateFile))
                {
                    var d = JsonSerializer.Deserialize<Dictionary<string, bool>>(File.ReadAllText(StateFile, Encoding.UTF8));
                    if (d != null) foreach (var kv in d) _state[kv.Key] = kv.Value;
                }
            }
            catch (Exception ex) { Console.Error.WriteLine("[Skills] state: " + ex.Message); }
            _sig = Signature();
        }
    }

    static Skill? Parse(string file)
    {
        string raw = File.ReadAllText(file, Encoding.UTF8).Replace("\r\n", "\n").TrimStart('\uFEFF');
        var s = new Skill { Id = Path.GetFileNameWithoutExtension(file), File = file, Text = raw.Trim() };
        if (raw.StartsWith("---\n"))
        {
            int end = raw.IndexOf("\n---", 4, StringComparison.Ordinal);
            if (end > 0)
            {
                foreach (string line in raw.Substring(4, end - 4).Split('\n'))
                {
                    int c = line.IndexOf(':');
                    if (c <= 0) continue;
                    string k = line.Substring(0, c).Trim().ToLowerInvariant(), v = line.Substring(c + 1).Trim();
                    switch (k)
                    {
                        case "id": if (v.Length > 0) s.Id = v; break;
                        case "group": s.Group = v; break;
                        case "description": s.Description = v; break;
                        case "triggers": s.Triggers = v.Split(',').Select(x => x.Trim().ToLowerInvariant()).Where(x => x.Length > 0).ToArray(); break;
                        case "always": s.Always = v.Equals("true", StringComparison.OrdinalIgnoreCase); break;
                        case "default": s.DefaultOn = !v.Equals("off", StringComparison.OrdinalIgnoreCase); break;
                        case "temperature": if (double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out double t)) s.Temperature = t; break;
                        case "max_tokens": if (int.TryParse(v, out int m)) s.MaxTokens = m; break;
                    }
                }
                s.Text = raw.Substring(end + 4).Trim();
            }
        }
        return s.Text.Length == 0 ? null : s;
    }

    bool IsOn(Skill s) => s.Always || (_state.TryGetValue(s.Id, out bool v) ? v : s.DefaultOn);

    static int Score(Skill s, string low)
    {
        int score = 0;
        foreach (string t in s.Triggers)
        {
            if (t.StartsWith("re:"))
            {
                try { if (Regex.IsMatch(low, t.Substring(3), RegexOptions.IgnoreCase)) score++; } catch (ArgumentException) { }
            }
            else if (low.Contains(t)) score++;
        }
        return score;
    }

    // ------------------------------------------------------------ выбор навыков для запроса
    public SkillSelection Select(string text, IEnumerable<string> forced, bool auto)
    {
        Refresh();
        lock (_lock)
        {
            string low = (text ?? "").ToLowerInvariant();
            var fs = new HashSet<string>(forced, StringComparer.OrdinalIgnoreCase);
            var chosen = new List<Skill>();
            var scored = new List<(Skill s, int score)>();
            foreach (var s in _skills)
            {
                if (s.Always || fs.Contains(s.Id)) { chosen.Add(s); continue; }
                if (!auto || !IsOn(s)) continue;
                int sc = Score(s, low);
                if (sc > 0) scored.Add((s, sc));
            }
            chosen.AddRange(scored.OrderByDescending(x => x.score).Take(_maxAuto).Select(x => x.s));
            // Стабильный порядок: обязательные первыми — llama-server переиспользует кэш общего начала промпта.
            chosen = chosen.OrderBy(s => s.Always ? 0 : 1).ThenBy(s => s.Id, StringComparer.Ordinal).ToList();

            var sel = new SkillSelection { Ids = chosen.Select(s => s.Id).ToList() };
            var sb = new StringBuilder();
            foreach (var s in chosen)
            {
                if (sb.Length > 0) sb.Append("\n\n");
                if (!s.Always) sb.Append("## ").Append(s.Id).Append('\n');
                sb.Append(s.Text);
            }
            sel.Block = sb.ToString();
            var temps = chosen.Where(s => s.Temperature != null).Select(s => s.Temperature!.Value).ToList();
            if (temps.Count > 0) sel.Temperature = temps.Min();
            var maxes = chosen.Where(s => s.MaxTokens != null).Select(s => s.MaxTokens!.Value).ToList();
            if (maxes.Count > 0) sel.MaxTokens = maxes.Max();
            return sel;
        }
    }

    // ------------------------------------------------------------ команды чата
    public bool TryCommand(string text, out string? reply)
    {
        reply = null;
        var m = Regex.Match(text.Trim(), @"^/(skills?)(?:\s+(.*))?$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        if (!m.Success) return false;
        Refresh();
        string[] a = (m.Groups[2].Value ?? "").Split(new[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        string sub = a.Length > 0 ? a[0].ToLowerInvariant() : "";

        lock (_lock)
        {
            if (sub == "" && m.Groups[1].Value.Equals("skills", StringComparison.OrdinalIgnoreCase) || sub == "list") { reply = List(); return true; }
            if (sub == "reload") { Reload(); reply = "Навыки перечитаны: " + _skills.Count + ".\n\n" + List(); return true; }
            if (sub == "reset")
            {
                _state.Clear(); Save();
                reply = "Состояние сброшено к значениям по умолчанию.\n\n" + List(); return true;
            }
            if (sub == "show" && a.Length > 1)
            {
                var s = _skills.FirstOrDefault(x => x.Id.Equals(a[1], StringComparison.OrdinalIgnoreCase));
                reply = s == null ? "Навык не найден: " + a[1] : "**" + s.Id + "** (~" + s.EstTokens + " ток.)\n\n```\n" + s.Text + "\n```";
                return true;
            }
            if ((sub == "on" || sub == "off") && a.Length > 1)
            {
                bool on = sub == "on";
                var names = a.Skip(1).ToList();
                var hit = new List<string>(); var skipped = new List<string>();
                foreach (string name in names)
                {
                    var targets = name.Equals("all", StringComparison.OrdinalIgnoreCase)
                        ? _skills.ToList()
                        : _skills.Where(s => s.Id.Equals(name, StringComparison.OrdinalIgnoreCase) || s.Group.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
                    if (targets.Count == 0) { skipped.Add(name + " (нет такого)"); continue; }
                    foreach (var s in targets)
                    {
                        if (s.Always) { skipped.Add(s.Id + " (обязательный)"); continue; }
                        _state[s.Id] = on; hit.Add(s.Id);
                    }
                }
                Save();
                reply = (hit.Count > 0 ? (on ? "Включено: " : "Выключено: ") + string.Join(", ", hit) + ".\n" : "")
                      + (skipped.Count > 0 ? "Пропущено: " + string.Join(", ", skipped) + ".\n" : "") + "\n" + List();
                return true;
            }
            reply = "Команды: `/skills`, `/skill on|off <id|группа|all>`, `/skill show <id>`, `/skills reload`, `/skills reset`, `/use id1,id2 вопрос` (разово подключить навыки).";
            return true;
        }
    }

    void Save()
    {
        try { File.WriteAllText(StateFile, JsonSerializer.Serialize(_state), new UTF8Encoding(false)); _sig = Signature(); }
        catch (Exception ex) { Console.Error.WriteLine("[Skills] не удалось сохранить состояние: " + ex.Message); }
    }

    string List()
    {
        var sb = new StringBuilder();
        sb.AppendLine("| Навык | Статус | Группа | ~Токенов | Назначение |");
        sb.AppendLine("| --- | --- | --- | --- | --- |");
        foreach (var s in _skills.OrderBy(x => x.Group).ThenBy(x => x.Id))
            sb.AppendLine("| " + s.Id + " | " + (s.Always ? "всегда" : IsOn(s) ? "вкл" : "выкл") + " | " + s.Group + " | " + s.EstTokens + " | " + s.Description + " |");
        sb.AppendLine("\nАвтоподключение: до " + _maxAuto + " навыков на запрос по ключевым словам. Разово: `/use id вопрос`.");
        return sb.ToString();
    }

    // /use id1,id2 вопрос  ->  список навыков + оставшийся текст
    public static bool TryUse(string text, out List<string> ids, out string rest)
    {
        ids = new List<string>(); rest = text;
        var m = Regex.Match(text.Trim(), @"^/use\s+([\w\-,]+)\s*(.*)$", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        if (!m.Success) return false;
        ids = m.Groups[1].Value.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
        rest = m.Groups[2].Value.Trim();
        return true;
    }
}
