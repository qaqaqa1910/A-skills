using System.Net;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json.Nodes;

var builder = WebApplication.CreateBuilder(args);

// !!! ВАЖНО: оставьте здесь ВАШ отпечаток сертификата из текущего Program.cs !!!
const string thumbprint = " "; // Вставьте отпечаток действующего сертификата.

const string upstreamBase = "http://127.0.0.1:8080";
const string indexFile = @"O:\AI\Knowledge\Index\documents.jsonl";

// Настройки: appsettings.json (секции "Ai" и "Eva") или переменные окружения Ai__*, Eva__*
var aiOptions = builder.Configuration.GetSection("Ai").Get<AiOptions>() ?? new AiOptions();
var evaOptions = builder.Configuration.GetSection("Eva").Get<EvaOptions>() ?? new EvaOptions();
evaOptions.FileIndexFile = indexFile;

var eva = new EvaService(evaOptions, upstreamBase);
var skills = new SkillEngine(aiOptions.SkillsDir, aiOptions.MaxAutoSkills);
var tools = new ToolRunner(aiOptions, upstreamBase, eva);
var pipeline = new ChatPipeline(aiOptions, eva, skills, tools);

using var store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
store.Open(OpenFlags.ReadOnly);

var cert = store.Certificates
    .Find(X509FindType.FindByThumbprint, thumbprint.Replace(" ", ""), false)
    .OfType<X509Certificate2>()
    .FirstOrDefault();

if (cert is null || !cert.HasPrivateKey)
{
    throw new InvalidOperationException("Certificate not found or private key is unavailable.");
}

builder.WebHost.ConfigureKestrel(options =>
{
    // Только TLS 1.2/1.3. Набор шифров на Windows задаётся в SChannel скриптом Harden-Tls.ps1.
    options.ListenAnyIP(443, listen => listen.UseHttps(https =>
    {
        https.ServerCertificate = cert;
        https.SslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13;
    }));
});

var app = builder.Build();

Console.WriteLine(evaOptions.Enabled
    ? $"[Eva] Интеграция включена: {evaOptions.BaseUrl}, запись: {evaOptions.AllowWrite}, admin_mode: {evaOptions.AdminMode}"
    : "[Eva] Интеграция выключена (не заданы Eva:BaseUrl и Eva:Token).");
eva.StartBackgroundSync();

// HSTS: браузер будет ходить только по HTTPS
app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["Strict-Transport-Security"] = "max-age=31536000";
    await next();
});

using var handler = new SocketsHttpHandler
{
    AllowAutoRedirect = false,
    UseCookies = false,
    AutomaticDecompression = DecompressionMethods.None
};

using var client = new HttpClient(handler)
{
    Timeout = Timeout.InfiniteTimeSpan
};

// Графики, CSV и файлы /export
app.Use(async (ctx, next) =>
{
    if (await eva.TryHandleHttpAsync(ctx)) return;
    await next();
});

app.Run(async context =>
{
    byte[]? modifiedBody = null;

    bool isChat =
        HttpMethods.IsPost(context.Request.Method) &&
        context.Request.Path.Equals("/v1/chat/completions", StringComparison.OrdinalIgnoreCase);

    if (isChat)
    {
        using var input = new MemoryStream();
        await context.Request.Body.CopyToAsync(input, context.RequestAborted);
        byte[] originalBody = input.ToArray();
        modifiedBody = originalBody;

        try
        {
            JsonNode? root = JsonNode.Parse(originalBody);

            if (root is JsonObject json && json["messages"] is JsonArray messages)
            {
                bool stream = json["stream"] is JsonValue sv && sv.TryGetValue<bool>(out bool sb) && sb;
                string modelName = json["model"]?.ToString() ?? "local";
                string linkBase = $"{context.Request.Scheme}://{context.Request.Host}";

                PipelineResult pr = await pipeline.ProcessAsync(json, messages, linkBase, context.RequestAborted);

                if (pr.Slow is not null)
                {
                    await EvaService.WriteDirectReplyAsync(context, stream, pr.Slow(), modelName);
                    return;
                }
                if (pr.Direct is not null)
                {
                    await EvaService.WriteDirectReplyAsync(context, stream, pr.Direct, modelName);
                    return;
                }

                modifiedBody = Encoding.UTF8.GetBytes(json.ToJsonString());
            }
        }
        catch (System.Text.Json.JsonException ex)
        {
            // Не вмешиваемся в запросы с некорректным JSON.
            Console.Error.WriteLine($"[Proxy] Не удалось разобрать JSON: {ex.Message}");
        }
    }

    var target = new Uri(upstreamBase + context.Request.Path + context.Request.QueryString);

    using var outgoing = new HttpRequestMessage(new HttpMethod(context.Request.Method), target);

    if (isChat && modifiedBody is not null)
    {
        outgoing.Content = new ByteArrayContent(modifiedBody);
    }
    else if (context.Request.ContentLength != 0 || context.Request.Headers.ContainsKey("Transfer-Encoding"))
    {
        outgoing.Content = new StreamContent(context.Request.Body);
    }

    string[] excluded =
    {
        "Host", "Connection", "Keep-Alive", "Proxy-Authenticate", "Proxy-Authorization",
        "TE", "Trailer", "Transfer-Encoding", "Upgrade"
    };

    foreach (var header in context.Request.Headers)
    {
        if (excluded.Contains(header.Key, StringComparer.OrdinalIgnoreCase)) continue;

        // Тело могло измениться, поэтому длину пересчитает HttpClient.
        if (isChat && header.Key.Equals("Content-Length", StringComparison.OrdinalIgnoreCase)) continue;

        if (!outgoing.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray()))
        {
            outgoing.Content?.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray());
        }
    }

    using var upstream = await client.SendAsync(outgoing, HttpCompletionOption.ResponseHeadersRead, context.RequestAborted);

    context.Response.StatusCode = (int)upstream.StatusCode;

    foreach (var header in upstream.Headers)
    {
        if (!excluded.Contains(header.Key, StringComparer.OrdinalIgnoreCase))
            context.Response.Headers[header.Key] = header.Value.ToArray();
    }

    foreach (var header in upstream.Content.Headers)
    {
        if (!excluded.Contains(header.Key, StringComparer.OrdinalIgnoreCase))
            context.Response.Headers[header.Key] = header.Value.ToArray();
    }

    context.Response.Headers.Remove("transfer-encoding");

    await upstream.Content.CopyToAsync(context.Response.Body, context.RequestAborted);
});

app.Run();
