// =====================================================================
//  Tools.cs — инструменты AIProxy. Выполняются КОДОМ, а не моделью:
//    /check [язык] [код]   — проверка кода (PowerShell, Python, SQL, VBS, YAML/GitLab CI, JSON)
//    /fix   [язык] [код]   — проверка -> исправление моделью по ошибкам -> повторная проверка (макс. итераций ограничено)
//    /export docx|xlsx|html|md|txt|csv [текст] — файл из последнего ответа (или из текста команды)
//    /tools, /tool <имя> <текст> — внешние инструменты из папки Tools\*.json (добавляются без перекомпиляции)
//  Если код не передан, берётся последний блок кода из последнего ответа модели.
// =====================================================================
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

public sealed class CheckResult
{
    public List<string> Errors = new List<string>();
    public List<string> Warnings = new List<string>();
    public string Note = "";
}

sealed class ExtTool
{
    public string Name = "", Description = "", Command = "", Extension = ".txt";
    public string[] Args = Array.Empty<string>();
    public int Timeout = 30;
    public bool Enabled;
}

public sealed class ToolRunner
{
    readonly AiOptions _o;
    readonly HttpClient _llm;
    readonly HttpClient _http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
    readonly EvaService _eva;

    static readonly Regex Fence = new Regex(@"```([A-Za-z0-9_+\-]*)[^\n]*\n(.*?)```", RegexOptions.Singleline | RegexOptions.Compiled);
    static readonly string[] Commands = { "/check", "/fix", "/export", "/tools", "/tool" };

    public ToolRunner(AiOptions o, string upstreamBase, EvaService eva)
    {
        _o = o;
        _eva = eva;
        _llm = new HttpClient { BaseAddress = new Uri(upstreamBase), Timeout = TimeSpan.FromMinutes(10) };
        Directory.CreateDirectory(_o.ToolsDir);
    }

    public bool TryParse(string text, out string cmd, out string arg)
    {
        foreach (string c in Commands)
        {
            if (text.Equals(c, StringComparison.OrdinalIgnoreCase) ||
                (text.StartsWith(c, StringComparison.OrdinalIgnoreCase) && text.Length > c.Length && char.IsWhiteSpace(text[c.Length])))
            {
                cmd = c; arg = text.Substring(c.Length).Trim(); return true;
            }
        }
        cmd = ""; arg = ""; return false;
    }

    public async Task<string> HandleAsync(string cmd, string arg, JsonArray messages, string linkBase, CancellationToken ct)
    {
        try
        {
            switch (cmd)
            {
                case "/check": return await CheckCommandAsync(arg, messages, ct);
                case "/export": return Export(arg, messages, linkBase);
                case "/tools": return ListTools();
                case "/tool": return await RunExternalAsync(arg, ct);
            }
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex) { return "⚠ Ошибка инструмента: " + ex.Message; }
        return "Неизвестная команда.";
    }

    // =================================================================
    //  Источник кода
    // =================================================================
    static readonly string[] Langs = { "ps", "ps1", "powershell", "pwsh", "python", "py", "sql", "tsql", "vbs", "vbscript", "yaml", "yml", "json" };

    static string? NormLang(string? l)
    {
        switch ((l ?? "").ToLowerInvariant())
        {
            case "ps": case "ps1": case "powershell": case "pwsh": return "ps";
            case "python": case "py": case "python3": return "python";
            case "sql": case "tsql": case "psql": case "pgsql": case "mysql": case "plsql": return "sql";
            case "vbs": case "vbscript": case "vb": return "vbs";
            case "yaml": case "yml": return "yaml";
            case "json": return "json";
            default: return null;
        }
    }

    static string Guess(string code)
    {
        if (Regex.IsMatch(code, @"(?im)^\s*(stages|script|image|include|variables)\s*:|^\.?[\w\-]+:\s*$")) return "yaml";
        if (Regex.IsMatch(code, @"(?i)\b(param\s*\(|Write-Host|Get-[A-Z]\w+|\$_\b|Set-StrictMode)")) return "ps";
        if (Regex.IsMatch(code, @"(?m)^\s*(def |import |from \w+ import|class \w+)")) return "python";
        if (Regex.IsMatch(code, @"(?i)\b(Dim |WScript\.|Option Explicit|End Sub|CreateObject)")) return "vbs";
        if (Regex.IsMatch(code, @"(?i)\b(select|insert\s+into|update|delete\s+from|create\s+table|alter\s+table)\b")) return "sql";
        if (code.TrimStart().StartsWith("{") || code.TrimStart().StartsWith("[")) return "json";
        return "";
    }

    static string LastAssistant(JsonArray messages)
    {
        for (int i = messages.Count - 1; i >= 0; i--)
            if (messages[i] is JsonObject m && string.Equals(m["role"]?.ToString(), "assistant", StringComparison.OrdinalIgnoreCase))
                return MsgUtil.GetText(m);
        return "";
    }

    static List<(string lang, string code)> Source(string arg, JsonArray messages)
    {
        string hint = "";
        var first = Regex.Match(arg, @"^(\S+)\s*(.*)$", RegexOptions.Singleline);
        if (first.Success && Langs.Contains(first.Groups[1].Value.ToLowerInvariant()))
        {
            hint = NormLang(first.Groups[1].Value) ?? "";
            arg = first.Groups[2].Value;
        }
        string text = arg.Trim().Length > 0 ? arg : LastAssistant(messages);
        var list = new List<(string, string)>();
        foreach (Match m in Fence.Matches(text))
            list.Add((NormLang(m.Groups[1].Value) ?? hint, m.Groups[2].Value.TrimEnd()));
        if (list.Count == 0 && arg.Trim().Length > 0) list.Add((hint, arg.Trim()));
        return list.Select(x => (x.Item1.Length > 0 ? x.Item1 : Guess(x.Item2), x.Item2)).ToList();
    }

    // =================================================================
    //  /check
    // =================================================================
    async Task<string> CheckCommandAsync(string arg, JsonArray messages, CancellationToken ct)
    {
        var blocks = Source(arg, messages);
        if (blocks.Count == 0) return "Нет кода для проверки. Передайте код после команды или сначала получите ответ модели с блоком кода.";
        var sb = new StringBuilder();
        int n = 0;
        foreach (var (lang, code) in blocks.Take(5))
        {
            n++;
            if (lang.Length == 0) { sb.AppendLine("**Блок " + n + ":** язык не определён. Укажите: `/check ps1|python|sql|vbs|yaml|json`.\n"); continue; }
            var r = await CheckAsync(lang, code, ct);
            sb.AppendLine(Format(lang, n, r));
        }
        return sb.ToString().TrimEnd();
    }

    static string Format(string lang, int n, CheckResult r)
    {
        var sb = new StringBuilder();
        string status = r.Errors.Count == 0 ? "✅ ошибок не найдено" : "❌ ошибок: " + r.Errors.Count;
        sb.AppendLine("**Блок " + n + " (" + lang + "):** " + status + (r.Warnings.Count > 0 ? ", предупреждений: " + r.Warnings.Count : ""));
        foreach (string e in r.Errors) sb.AppendLine("- ❌ " + e);
        foreach (string w in r.Warnings) sb.AppendLine("- ⚠ " + w);
        if (r.Note.Length > 0) sb.AppendLine("_" + r.Note + "_");
        return sb.ToString();
    }

    async Task<CheckResult> CheckAsync(string lang, string code, CancellationToken ct)
    {
        switch (lang)
        {
            case "ps": return await CheckPsAsync(code, ct);
            case "python": return await CheckPythonAsync(code, ct);
            case "sql": return CheckSql(code);
            case "vbs": return CheckVbs(code);
            case "yaml": return await CheckYamlAsync(code, ct);
            case "json": return CheckJson(code);
            default: return new CheckResult { Note = "Для языка «" + lang + "» проверка не реализована." };
        }
    }

    string Helper(string name)
    {
        string p = Path.Combine(_o.ToolsDir, name);
        if (!File.Exists(p)) throw new FileNotFoundException("Не найден вспомогательный файл " + p + " (скопируйте его из пакета Tools).");
        return p;
    }

    static void ParseTagged(string output, CheckResult r)
    {
        foreach (string raw in output.Replace("\r", "").Split('\n'))
        {
            string l = raw.Trim();
            if (l.StartsWith("ERR:")) r.Errors.Add(l.Substring(4).Trim());
            else if (l.StartsWith("WARN:")) r.Warnings.Add(l.Substring(5).Trim());
            else if (l.StartsWith("INFO:")) r.Note = l.Substring(5).Trim();
        }
    }

    async Task<CheckResult> CheckPsAsync(string code, CancellationToken ct)
    {
        var r = new CheckResult();
        string tmp = Path.Combine(Path.GetTempPath(), "aip-" + Guid.NewGuid().ToString("N") + ".ps1");
        File.WriteAllText(tmp, code, new UTF8Encoding(true));
        try
        {
            var (ec, so, se) = await RunProc("powershell.exe",
                new[] { "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", Helper("ps-parse.ps1"), "-Path", tmp }, 60, ct);
            ParseTagged(so, r);
            if (ec != 0 && r.Errors.Count == 0) r.Warnings.Add("Проверка завершилась с кодом " + ec + ": " + Trunc(se, 300));
        }
        catch (Win32Exception) { r.Note = "powershell.exe не найден."; }
        finally { try { File.Delete(tmp); } catch { } }
        return r;
    }

    async Task<CheckResult> CheckPythonAsync(string code, CancellationToken ct)
    {
        var r = new CheckResult();
        string tmp = Path.Combine(Path.GetTempPath(), "aip-" + Guid.NewGuid().ToString("N") + ".py");
        File.WriteAllText(tmp, code, new UTF8Encoding(false));
        try
        {
            var (ec, so, se) = await RunProc(_o.PythonPath, new[] { Helper("py-check.py"), tmp }, 30, ct);
            ParseTagged(so, r);
            if (ec != 0 && r.Errors.Count == 0) r.Warnings.Add("Проверка завершилась с кодом " + ec + ": " + Trunc(se, 300));
        }
        catch (Win32Exception) { r.Note = "Python не найден (параметр Ai:PythonPath)."; }
        finally { try { File.Delete(tmp); } catch { } }
        return r;
    }

    static CheckResult CheckSql(string code)
    {
        var r = new CheckResult { Note = "Эвристика: синтаксис конкретной СУБД не проверялся. Проверьте в тестовой базе." };
        string s = Regex.Replace(code, @"--[^\n]*", " ");
        s = Regex.Replace(s, @"/\*.*?\*/", " ", RegexOptions.Singleline);
        if (s.Count(c => c == '\'') % 2 != 0) r.Errors.Add("Нечётное число одинарных кавычек: возможно, строка не закрыта.");
        string noStr = Regex.Replace(s, @"'([^']|'')*'", "''");
        int depth = 0;
        foreach (char c in noStr)
        {
            if (c == '(') depth++;
            else if (c == ')') { depth--; if (depth < 0) { r.Errors.Add("Лишняя закрывающая скобка."); depth = 0; } }
        }
        if (depth > 0) r.Errors.Add("Незакрытых скобок: " + depth + ".");
        foreach (string stmt in noStr.Split(';'))
        {
            string u = stmt.Trim().ToUpperInvariant();
            if (u.Length == 0) continue;
            if ((u.StartsWith("UPDATE") || u.StartsWith("DELETE")) && !Regex.IsMatch(u, @"\bWHERE\b"))
                r.Warnings.Add("Оператор " + u.Split(' ')[0] + " без WHERE изменит все строки таблицы.");
            if (Regex.IsMatch(u, @"^(DROP|TRUNCATE)\b")) r.Warnings.Add("Деструктивная команда " + u.Split(' ')[0] + ": убедитесь, что это нужно.");
            if (Regex.IsMatch(u, @"\bSELECT\s+\*")) r.Warnings.Add("SELECT * — перечислите нужные столбцы.");
            if (Regex.IsMatch(u, @"\bJOIN\b") && !Regex.IsMatch(u, @"\b(ON|USING)\b") && !Regex.IsMatch(u, @"\bCROSS\s+JOIN\b|\bNATURAL\b|\bAPPLY\b"))
                r.Warnings.Add("JOIN без ON/USING даст декартово произведение.");
        }
        return r;
    }

    static CheckResult CheckVbs(string code)
    {
        var r = new CheckResult { Note = "Эвристика: полного разбора VBScript без запуска скрипта нет; проверены парность блоков и частые ошибки." };
        var raw = code.Replace("\r", "").Split('\n');
        // склеиваем строки с продолжением « _»
        var lines = new List<(int no, string text)>();
        var acc = new StringBuilder(); int startNo = 1;
        for (int i = 0; i < raw.Length; i++)
        {
            if (acc.Length == 0) startNo = i + 1;
            string l = raw[i].TrimEnd();
            if (l.EndsWith(" _")) { acc.Append(l, 0, l.Length - 2).Append(' '); continue; }
            acc.Append(l);
            lines.Add((startNo, acc.ToString())); acc.Clear();
        }
        var stack = new Stack<(string kind, int no)>();
        bool optionExplicit = false;
        int resumeNext = 0;
        foreach (var (no, text0) in lines)
        {
            string t = Regex.Replace(text0, "\"([^\"]|\"\")*\"", "\"\"");
            int c = t.IndexOf('\''); if (c >= 0) t = t.Substring(0, c);
            t = t.Trim().ToLowerInvariant();
            if (t.Length == 0 || t.StartsWith("rem ") || t == "rem") continue;
            if (t.StartsWith("option explicit")) optionExplicit = true;
            if (t.Contains("on error resume next")) resumeNext++;

            var end = Regex.Match(t, @"^end\s+(sub|function|class|property|if|select|with)\b");
            if (end.Success) { Pop(stack, end.Groups[1].Value, no, r); continue; }
            if (Regex.IsMatch(t, @"^next\b")) { Pop(stack, "for", no, r); continue; }
            if (Regex.IsMatch(t, @"^wend\b")) { Pop(stack, "while", no, r); continue; }
            if (Regex.IsMatch(t, @"^loop\b")) { Pop(stack, "do", no, r); continue; }

            var open = Regex.Match(t, @"^(?:public\s+|private\s+)?(?:default\s+)?(sub|function|class|property)\b");
            if (open.Success) { stack.Push((open.Groups[1].Value, no)); continue; }
            if (Regex.IsMatch(t, @"^for\b")) { stack.Push(("for", no)); continue; }
            if (Regex.IsMatch(t, @"^while\b")) { stack.Push(("while", no)); continue; }
            if (Regex.IsMatch(t, @"^do\b")) { stack.Push(("do", no)); continue; }
            if (Regex.IsMatch(t, @"^select\s+case\b")) { stack.Push(("select", no)); continue; }
            if (Regex.IsMatch(t, @"^with\b")) { stack.Push(("with", no)); continue; }
            if (Regex.IsMatch(t, @"^if\b.*\bthen$")) { stack.Push(("if", no)); continue; }
            if (Regex.IsMatch(t, @"^(var |let |const |function\s*\(|=>)") || t.Contains("};")) r.Warnings.Add("Строка " + no + ": похоже на синтаксис другого языка.");
        }
        foreach (var (kind, no) in stack) r.Errors.Add("Блок «" + kind + "» (строка " + no + ") не закрыт.");
        if (!optionExplicit) r.Warnings.Add("Нет Option Explicit — опечатки в именах переменных не будут обнаружены.");
        if (resumeNext > 0) r.Warnings.Add("On Error Resume Next (" + resumeNext + " раз): ограничивайте одним оператором и проверяйте Err.Number.");
        return r;
    }

    static void Pop(Stack<(string kind, int no)> st, string expect, int no, CheckResult r)
    {
        if (st.Count == 0) { r.Errors.Add("Строка " + no + ": закрывающая конструкция «" + expect + "» без открывающей."); return; }
        var top = st.Pop();
        if (top.kind != expect) r.Errors.Add("Строка " + no + ": ожидалось закрытие «" + top.kind + "» (открыто в строке " + top.no + "), найдено «" + expect + "».");
    }

    static CheckResult CheckJson(string code)
    {
        var r = new CheckResult();
        try { using var d = JsonDocument.Parse(code); }
        catch (JsonException ex) { r.Errors.Add("JSON: " + ex.Message + (ex.LineNumber != null ? " (строка " + (ex.LineNumber + 1) + ")" : "")); }
        return r;
    }

    async Task<CheckResult> CheckYamlAsync(string code, CancellationToken ct)
    {
        var r = new CheckResult();
        var lines = code.Replace("\r", "").Split('\n');
        var seen = new Dictionary<string, int>();
        for (int i = 0; i < lines.Length; i++)
        {
            string l = lines[i];
            if (Regex.IsMatch(l, @"^\s*\t")) r.Errors.Add("Строка " + (i + 1) + ": табуляция в отступе — в YAML допустимы только пробелы.");
            var m = Regex.Match(l, @"^([A-Za-z_.][^\s:#]*):(\s|$)");
            if (m.Success)
            {
                if (seen.TryGetValue(m.Groups[1].Value, out int first))
                    r.Errors.Add("Строка " + (i + 1) + ": ключ «" + m.Groups[1].Value + "» повторяется (первый раз в строке " + first + ") — второй перезапишет первый.");
                else seen[m.Groups[1].Value] = i + 1;
            }
        }
        if (r.Errors.Count > 0) { r.Note = "GitLab CI Lint не запускался: сначала исправьте базовые ошибки."; return r; }

        if (string.IsNullOrWhiteSpace(_o.GitlabUrl) || string.IsNullOrWhiteSpace(_o.GitlabToken) || string.IsNullOrWhiteSpace(_o.GitlabLintProjectId))
        {
            r.Note = "GitLab CI Lint не настроен (Ai:GitlabUrl, Ai:GitlabToken, Ai:GitlabLintProjectId) — выполнена только базовая проверка.";
            return r;
        }
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Post,
                _o.GitlabUrl.TrimEnd('/') + "/api/v4/projects/" + Uri.EscapeDataString(_o.GitlabLintProjectId) + "/ci/lint");
            req.Headers.Add("PRIVATE-TOKEN", _o.GitlabToken);
            req.Content = new StringContent(new JsonObject { ["content"] = code, ["dry_run"] = false }.ToJsonString(), Encoding.UTF8, "application/json");
            using var resp = await _http.SendAsync(req, ct);
            string body = await resp.Content.ReadAsStringAsync(ct);
            if (!resp.IsSuccessStatusCode) { r.Warnings.Add("GitLab Lint недоступен: HTTP " + (int)resp.StatusCode + " " + Trunc(body, 200)); return r; }
            var j = JsonNode.Parse(body);
            bool valid = (j?["valid"]?.ToString() ?? "").Equals("true", StringComparison.OrdinalIgnoreCase);
            if (j?["errors"] is JsonArray ea) foreach (var e in ea) r.Errors.Add("GitLab: " + e);
            if (j?["warnings"] is JsonArray wa) foreach (var w in wa) r.Warnings.Add("GitLab: " + w);
            if (!valid && r.Errors.Count == 0) r.Errors.Add("GitLab: конфигурация признана недействительной.");
            r.Note = "Проверено GitLab CI Lint (результат реальной системы).";
        }
        catch (Exception ex) when (ex is HttpRequestException || ex is TaskCanceledException)
        {
            r.Warnings.Add("GitLab Lint недоступен: " + ex.Message);
        }
        return r;
    }

    // =================================================================
    //  /fix: проверка -> модель исправляет только указанные ошибки -> повторная проверка
    // =================================================================
    public async Task<string> FixAsync(string arg, JsonArray messages, CancellationToken ct)
    {
        try
        {
            var blocks = Source(arg, messages);
            if (blocks.Count == 0) return "Нет кода для исправления.";
            var (lang, code) = blocks[blocks.Count - 1];
            if (lang.Length == 0) return "Не удалось определить язык. Укажите: `/fix ps1|python|sql|vbs|yaml|json`.";

            var res = await CheckAsync(lang, code, ct);
            if (res.Errors.Count == 0) return "✅ Ошибок не найдено, исправлять нечего.\n\n" + Format(lang, 1, res);

            int it = 0;
            while (res.Errors.Count > 0 && it < _o.MaxFixIterations)
            {
                it++;
                code = await AskFixAsync(lang, code, res.Errors, ct);
                res = await CheckAsync(lang, code, ct);
            }
            var sb = new StringBuilder();
            sb.AppendLine(res.Errors.Count == 0
                ? "✅ Исправлено за " + it + " поп., проверка пройдена."
                : "⚠ После " + it + " поп. остались ошибки — требуется ручная правка.");
            sb.AppendLine("\n```" + (lang == "ps" ? "powershell" : lang) + "\n" + code + "\n```\n");
            sb.Append(Format(lang, 1, res));
            return sb.ToString();
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex) { return "⚠ Ошибка /fix: " + ex.Message; }
    }

    async Task<string> AskFixAsync(string lang, string code, List<string> errors, CancellationToken ct)
    {
        string user = "Language: " + lang + "\nValidator errors:\n- " + string.Join("\n- ", errors) + "\n\nCode:\n```\n" + code + "\n```";
        var req = new JsonObject
        {
            ["messages"] = new JsonArray
            {
                new JsonObject { ["role"] = "system", ["content"] = "Fix ONLY the listed validator errors. Keep everything else unchanged. Output the full corrected code in ONE fenced code block and nothing else. Comments in Russian." },
                new JsonObject { ["role"] = "user", ["content"] = user }
            },
            ["temperature"] = 0.1, ["max_tokens"] = 2500, ["stream"] = false, ["cache_prompt"] = true
        };
        using var content = new StringContent(req.ToJsonString(), Encoding.UTF8, "application/json");
        using var resp = await _llm.PostAsync("/v1/chat/completions", content, ct);
        string body = await resp.Content.ReadAsStringAsync(ct);
        if (!resp.IsSuccessStatusCode) throw new InvalidOperationException("Модель вернула HTTP " + (int)resp.StatusCode);
        string text = JsonNode.Parse(body)?["choices"]?[0]?["message"]?["content"]?.ToString() ?? "";
        var m = Fence.Match(text);
        return (m.Success ? m.Groups[2].Value : text).TrimEnd();
    }

    // =================================================================
    //  /export
    // =================================================================
    string Export(string arg, JsonArray messages, string linkBase)
    {
        var m = Regex.Match(arg, @"^(\S+)\s*(.*)$", RegexOptions.Singleline);
        string fmt = m.Success ? m.Groups[1].Value.ToLowerInvariant() : "";
        string[] ok = { "docx", "xlsx", "html", "md", "txt", "csv" };
        if (!ok.Contains(fmt))
            return "Использование: `/export docx|xlsx|html|md|txt|csv [текст]`. Без текста берётся последний ответ модели.\nPDF: `/export html`, затем открыть файл в браузере и «Печать → Сохранить как PDF».";
        string md = m.Groups[2].Value.Trim();
        if (md.Length == 0) md = LastAssistant(messages);
        if (md.Trim().Length == 0) return "Нет текста для экспорта.";

        var blocks = DocExport.Parse(md);
        string title = DocExport.Title(blocks);
        string baseName = Regex.Replace(title, @"[^\p{L}\p{N}\-_ ]", "").Trim().Replace(' ', '_');
        if (baseName.Length == 0) baseName = "document";
        if (baseName.Length > 40) baseName = baseName.Substring(0, 40);
        baseName += "-" + DateTime.Now.ToString("yyyyMMdd-HHmm");

        byte[] data;
        switch (fmt)
        {
            case "docx": data = DocExport.ToDocx(blocks); break;
            case "xlsx": data = DocExport.ToXlsx(blocks); break;
            case "html": data = Encoding.UTF8.GetBytes(DocExport.ToHtml(blocks)); break;
            case "md": data = new UTF8Encoding(true).GetPreamble().Concat(Encoding.UTF8.GetBytes(md)).ToArray(); break;
            case "txt":
                string plain = Regex.Replace(md, @"(?m)^#{1,6}\s+", "");
                plain = Regex.Replace(plain, @"\*\*([^*]+)\*\*", "$1");
                plain = Regex.Replace(plain, @"```[A-Za-z0-9]*\n?", "");
                data = new UTF8Encoding(true).GetPreamble().Concat(Encoding.UTF8.GetBytes(plain)).ToArray(); break;
            default:
                string? csv = DocExport.ToCsv(blocks);
                if (csv == null) return "В тексте нет таблицы Markdown для CSV.";
                data = new UTF8Encoding(true).GetPreamble().Concat(Encoding.UTF8.GetBytes(csv)).ToArray(); break;
        }
        string name = _eva.PutFile(fmt, data, baseName + "." + fmt);
        return "📎 [" + baseName + "." + fmt + "](" + linkBase.TrimEnd('/') + "/eva/files/" + name + ")";
    }

    // =================================================================
    //  Внешние инструменты: Tools\*.json
    //  {"name":"имя","description":"English description","command":"powershell.exe",
    //   "args":["-NoProfile","-File","{tools}\\my.ps1","-Path","{file}"],"extension":".txt","timeout":30,"enabled":true}
    // =================================================================
    List<ExtTool> LoadExt()
    {
        var list = new List<ExtTool>();
        foreach (string f in Directory.GetFiles(_o.ToolsDir, "*.json"))
        {
            try
            {
                var j = JsonNode.Parse(File.ReadAllText(f, Encoding.UTF8)) as JsonObject;
                if (j == null) continue;
                list.Add(new ExtTool
                {
                    Name = j["name"]?.ToString() ?? Path.GetFileNameWithoutExtension(f),
                    Description = j["description"]?.ToString() ?? "",
                    Command = j["command"]?.ToString() ?? "",
                    Extension = j["extension"]?.ToString() ?? ".txt",
                    Args = (j["args"] as JsonArray)?.Select(x => x?.ToString() ?? "").ToArray() ?? Array.Empty<string>(),
                    Timeout = int.TryParse(j["timeout"]?.ToString(), out int t) ? Math.Clamp(t, 1, 300) : 30,
                    Enabled = !(j["enabled"]?.ToString() ?? "true").Equals("false", StringComparison.OrdinalIgnoreCase)
                });
            }
            catch (Exception ex) { Console.Error.WriteLine("[Tools] " + f + ": " + ex.Message); }
        }
        return list;
    }

    string ListTools()
    {
        var sb = new StringBuilder();
        sb.AppendLine("| Инструмент | Что делает |");
        sb.AppendLine("| --- | --- |");
        sb.AppendLine("| /check [язык] [код] | Проверка кода: ps1, python, sql, vbs, yaml (GitLab CI), json |");
        sb.AppendLine("| /fix [язык] [код] | Проверка → исправление моделью → повторная проверка (до " + _o.MaxFixIterations + " итераций) |");
        sb.AppendLine("| /export docx\\|xlsx\\|html\\|md\\|txt\\|csv | Файл из последнего ответа |");
        foreach (var t in LoadExt())
            sb.AppendLine("| /tool " + t.Name + " | " + (t.Enabled ? "" : "(выключен) ") + t.Description + " |");
        return sb.ToString();
    }

    async Task<string> RunExternalAsync(string arg, CancellationToken ct)
    {
        var m = Regex.Match(arg, @"^(\S+)\s*(.*)$", RegexOptions.Singleline);
        if (!m.Success) return ListTools();
        var tool = LoadExt().FirstOrDefault(t => t.Name.Equals(m.Groups[1].Value, StringComparison.OrdinalIgnoreCase));
        if (tool == null || !tool.Enabled) return "Инструмент не найден или выключен. Список: `/tools`.";
        string input = m.Groups[2].Value;
        var fence = Fence.Match(input);
        if (fence.Success) input = fence.Groups[2].Value;

        string tmp = Path.Combine(Path.GetTempPath(), "aip-" + Guid.NewGuid().ToString("N") + tool.Extension);
        File.WriteAllText(tmp, input, new UTF8Encoding(true));
        try
        {
            var args = tool.Args.Select(a => a.Replace("{file}", tmp).Replace("{tools}", _o.ToolsDir));
            var (ec, so, se) = await RunProc(tool.Command, args, tool.Timeout, ct);
            string outText = Trunc((so + (se.Length > 0 ? "\n" + se : "")).Trim(), 4000);
            return "Код возврата: " + ec + "\n```\n" + outText + "\n```";
        }
        catch (Win32Exception) { return "Команда не найдена: " + tool.Command; }
        catch (TimeoutException ex) { return "⚠ " + ex.Message; }
        finally { try { File.Delete(tmp); } catch { } }
    }

    // =================================================================
    static async Task<(int code, string stdout, string stderr)> RunProc(string file, IEnumerable<string> args, int timeoutSec, CancellationToken ct)
    {
        var psi = new ProcessStartInfo
        {
            FileName = file, UseShellExecute = false, CreateNoWindow = true,
            RedirectStandardOutput = true, RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
        };
        foreach (string a in args) psi.ArgumentList.Add(a);
        using var p = Process.Start(psi) ?? throw new InvalidOperationException("Не удалось запустить " + file);
        var so = p.StandardOutput.ReadToEndAsync();
        var se = p.StandardError.ReadToEndAsync();
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(TimeSpan.FromSeconds(timeoutSec));
        try { await p.WaitForExitAsync(cts.Token); }
        catch (OperationCanceledException)
        {
            try { p.Kill(true); } catch { }
            throw new TimeoutException("Превышено время выполнения (" + timeoutSec + " с).");
        }
        return (p.ExitCode, await so, await se);
    }

    static string Trunc(string s, int max) => s.Length <= max ? s : s.Substring(0, max) + "…";
}
