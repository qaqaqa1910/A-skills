// =====================================================================
//  Knowledge.cs — поиск по локальным индексам (файлы + документы EvaTeam).
//  Общий для AIProxy и Indexer. BM25 + русский стеммер + буст заголовков
//  + проверка уверенности: если надёжного совпадения нет — модель не вызывается.
// =====================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

public sealed class KnowledgeChunk
{
    public string Source { get; set; } = "";
    public int Part { get; set; }
    public string Heading { get; set; } = "";
    public string Text { get; set; } = "";
    [JsonIgnore] public Dictionary<string, int>? Terms { get; set; }
    [JsonIgnore] public HashSet<string>? HeadTerms { get; set; }
    [JsonIgnore] public int Len { get; set; }
}

public sealed class FindResult
{
    public List<KnowledgeChunk> Chunks = new List<KnowledgeChunk>();
    public bool Confident;
    public bool Ambiguous;                       // несколько разных документов подходят одинаково хорошо
    public List<string> Candidates = new List<string>(); // «ближайшие разделы», если уверенности нет
}

public static class Knowledge
{
    sealed class Corpus
    {
        public List<KnowledgeChunk> Chunks = new List<KnowledgeChunk>();
        public Dictionary<string, int> Df = new Dictionary<string, int>();
        public double AvgLen = 1;
    }

    static readonly object Gate = new object();
    static string _key = "";
    static Corpus _corpus = new Corpus();

    static readonly Regex Splitter = new Regex(@"[^\p{L}\p{N}_]+", RegexOptions.Compiled);
    static readonly Regex CodeRx = new Regex(@"\b[A-Za-z]{2,10}-\d{2,}\b", RegexOptions.Compiled);
    static readonly JsonSerializerOptions Opt = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

    static readonly HashSet<string> Stop = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "как","что","это","для","при","или","где","когда","если","какой","какая","какие","какое","нужно","надо",
        "есть","был","была","было","быть","будет","мне","нам","наш","наша","наши","этот","эта","эти","того","чтобы",
        "про","под","над","после","перед","внутри","можно","можете","могу","пожалуйста","скажи","подскажи","расскажи",
        "объясни","опиши","покажи","найди","документации","документе","документ","инструкции","инструкция",
        "about","what","where","when","with","from","this","that","the","and","for","how"
    };

    static readonly string[] RuSuffixes = (
        "иями,ями,ами,ией,ого,его,ому,ему,ыми,ими,ешь,ишь,ете,ите,ать,ять,еть,ить,ыть,ует,уют,ает,яет,ают,яют," +
        "ся,сь,ов,ев,ей,ой,ий,ый,ая,яя,ое,ее,ые,ие,ых,их,ом,ем,ам,ям,ах,ях,ую,юю,ою,ею,ет,ют,ут,ит,ят,ла,ли,ло,на,ть," +
        "а,я,о,е,ы,и,у,ю,ь,й")
        .Split(',').OrderByDescending(s => s.Length).ToArray();

    public static string Stem(string w)
    {
        if (w.Length <= 4 || w.Any(char.IsDigit) || w.Contains('_')) return w;
        if (w[0] >= 'a' && w[0] <= 'z')
        {
            foreach (string s in new[] { "ing", "ed", "es", "s" })
                if (w.EndsWith(s, StringComparison.Ordinal) && w.Length - s.Length >= 4) return w.Substring(0, w.Length - s.Length);
            return w;
        }
        foreach (string s in RuSuffixes)
            if (w.EndsWith(s, StringComparison.Ordinal) && w.Length - s.Length >= 3) return w.Substring(0, w.Length - s.Length);
        return w;
    }

    static IEnumerable<string> Tokens(string text)
        => Splitter.Split(text.ToLowerInvariant()).Where(t => t.Length >= 2);

    // ------------------------------------------------------------ загрузка
    static Corpus Load(IEnumerable<string> files)
    {
        var list = files.Where(File.Exists).ToList();
        string key = string.Join("|", list.Select(f => { var fi = new FileInfo(f); return f + ":" + fi.LastWriteTimeUtc.Ticks + ":" + fi.Length; }));
        lock (Gate)
        {
            if (key == _key) return _corpus;
            var c = new Corpus();
            foreach (string file in list)
            {
                try
                {
                    foreach (string line in File.ReadLines(file, Encoding.UTF8))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        KnowledgeChunk? ch;
                        try { ch = JsonSerializer.Deserialize<KnowledgeChunk>(line, Opt); }
                        catch (JsonException) { continue; }
                        if (ch == null || string.IsNullOrWhiteSpace(ch.Text)) continue;

                        var terms = new Dictionary<string, int>();
                        int len = 0;
                        foreach (string tok in Tokens(ch.Text))
                        {
                            string st = Stem(tok);
                            terms[st] = terms.TryGetValue(st, out int n) ? n + 1 : 1;
                            len++;
                        }
                        ch.Terms = terms;
                        ch.Len = Math.Max(1, len);
                        ch.HeadTerms = new HashSet<string>(Tokens(ch.Heading ?? "").Select(Stem));
                        foreach (string t in terms.Keys) c.Df[t] = c.Df.TryGetValue(t, out int d) ? d + 1 : 1;
                        c.Chunks.Add(ch);
                    }
                }
                catch (IOException) { /* файл пересобирается — берём то, что успели */ }
            }
            c.AvgLen = c.Chunks.Count == 0 ? 1 : c.Chunks.Average(x => x.Len);
            _corpus = c;
            _key = key;
            return c;
        }
    }

    // ------------------------------------------------------------ поиск
    public static FindResult Search(string query, IEnumerable<string> files, int max, double minCoverage)
    {
        var res = new FindResult();
        var corpus = Load(files);
        var terms = Tokens(query).Where(t => t.Length >= 3 && !Stop.Contains(t)).Select(Stem).Distinct().ToList();
        var codes = CodeRx.Matches(query).Cast<Match>().Select(m => m.Value).Distinct().ToList();
        if (terms.Count == 0 && codes.Count == 0) return res;

        int N = Math.Max(1, corpus.Chunks.Count);
        const double k1 = 1.2, b = 0.75;
        var scored = new List<(KnowledgeChunk c, double score, int matched, bool code)>();

        foreach (var ch in corpus.Chunks)
        {
            double score = 0; int matched = 0;
            foreach (string t in terms)
            {
                if (!ch.Terms!.TryGetValue(t, out int tf)) continue;
                matched++;
                corpus.Df.TryGetValue(t, out int df);
                double idf = Math.Log(1 + (N - df + 0.5) / (df + 0.5));
                double s = idf * tf * (k1 + 1) / (tf + k1 * (1 - b + b * ch.Len / corpus.AvgLen));
                if (ch.HeadTerms!.Contains(t)) s *= 1.8;   // совпадение в заголовке важнее
                score += s;
            }
            bool code = codes.Any(cd => ch.Text.IndexOf(cd, StringComparison.OrdinalIgnoreCase) >= 0);
            if (code) score += 6;
            if (matched > 0 || code) scored.Add((ch, score, matched, code));
        }

        var ordered = scored.OrderByDescending(x => x.score).ToList();
        int n = terms.Count;
        int required = n <= 2 ? n : (int)Math.Ceiling(n * minCoverage);

        var ok = ordered.Where(x => x.code || x.matched >= required).ToList();
        if (ok.Count == 0)
        {
            res.Candidates = ordered.Take(3).Select(x => x.c.Source + " — " + x.c.Heading).Distinct().ToList();
            return res;
        }

        var chosen = new List<(KnowledgeChunk c, double score)>();
        var perSource = new Dictionary<string, int>();
        foreach (var x in ok)
        {
            perSource.TryGetValue(x.c.Source, out int cnt);
            if (cnt >= 2) continue;                      // не более 2 фрагментов из одного документа
            perSource[x.c.Source] = cnt + 1;
            chosen.Add((x.c, x.score));
            if (chosen.Count >= max) break;
        }
        res.Chunks = chosen.Select(x => x.c).ToList();
        res.Confident = true;
        res.Ambiguous = chosen.Count >= 2 && chosen[0].c.Source != chosen[1].c.Source && chosen[1].score >= 0.85 * chosen[0].score;
        return res;
    }

    public static string NotFoundText(string query, FindResult r)
    {
        var sb = new StringBuilder();
        sb.AppendLine("В документации не найдено надёжного подтверждения по запросу: «" + query + "».");
        if (r.Candidates.Count > 0)
        {
            sb.AppendLine("\nБлижайшие разделы (совпадение частичное, проверьте вручную):");
            foreach (string c in r.Candidates) sb.AppendLine("- " + c);
        }
        sb.Append("\nУточните запрос: точные термины, название документа или раздела.");
        return sb.ToString();
    }

    public static string BuildContext(List<KnowledgeChunk> chunks, int maxChars)
    {
        var sb = new StringBuilder();
        int i = 1;
        foreach (var ch in chunks)
        {
            string section = "\n--- [" + i++ + "] " + ch.Source + " ---\n" + ch.Text + "\n";
            int remaining = maxChars - sb.Length;
            if (remaining <= 0) break;
            if (section.Length > remaining)
            {
                if (remaining > 200) sb.Append(section.Substring(0, remaining));
                break;
            }
            sb.Append(section);
        }
        return sb.ToString();
    }
}
