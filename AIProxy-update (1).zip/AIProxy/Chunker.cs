// =====================================================================
//  Chunker.cs — ОБЩИЙ файл для AIProxy и Indexer (кладётся в оба проекта без изменений).
//  Режет текст по разделам и добавляет к каждому фрагменту «хлебные крошки»:
//  «Документ > Раздел > Подраздел». Благодаря этому модель и поиск различают
//  похожие разделы разных документов.
//  Вход: текст, где заголовки записаны как в Markdown (# ... ######).
// =====================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

public sealed class ChunkPiece
{
    public string Heading = "";
    public string Text = "";
}

public static class Chunker
{
    // Максимальный размер фрагмента. Меньше фрагмент — точнее поиск и дешевле промпт на CPU.
    public const int MaxChars = 1200;

    static readonly Regex MdHeading = new Regex(@"^(#{1,6})\s+(.+?)\s*#*\s*$", RegexOptions.Compiled);
    static readonly Regex NumHeading = new Regex(@"^(\d+(?:\.\d+){0,4})[\.\)]?\s+(\p{Lu}[^|]{2,90})$", RegexOptions.Compiled);
    static readonly Regex TableSep = new Regex(@"^\|?[\s:\-|]+\|?$", RegexOptions.Compiled);

    sealed class Section
    {
        public int Level;
        public string Trail = "";
        public string Own = "";
        public StringBuilder Body = new StringBuilder();
    }

    public static List<ChunkPiece> Split(string docTitle, string text)
    {
        var lines = (text ?? "").Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        bool hasMd = lines.Any(l => MdHeading.IsMatch(l.Trim()));

        var sections = new List<Section>();
        var stack = new List<(int level, string title)>();
        var cur = new Section { Level = 0, Trail = docTitle };
        sections.Add(cur);
        bool fence = false;

        foreach (string raw in lines)
        {
            string line = raw.TrimEnd();
            string t = line.Trim();
            if (t.StartsWith("```")) { fence = !fence; cur.Body.AppendLine(line); continue; }

            int level = 0; string title = "";
            if (!fence)
            {
                var m = MdHeading.Match(t);
                if (m.Success) { level = m.Groups[1].Length; title = m.Groups[2].Value.Trim(); }
                else if (!hasMd && t.Length <= 100 && !t.EndsWith(".") && !t.EndsWith(":") && !t.EndsWith(";"))
                {
                    // Документы без стилей заголовков: «1.2 Название раздела»
                    var n = NumHeading.Match(t);
                    if (n.Success) { level = n.Groups[1].Value.Split('.').Length; title = t; }
                }
            }

            if (level > 0)
            {
                while (stack.Count > 0 && stack[stack.Count - 1].level >= level) stack.RemoveAt(stack.Count - 1);
                stack.Add((level, title));
                string trail = docTitle + " > " + string.Join(" > ", stack.Select(s => s.title));
                if (trail.Length > 220) trail = trail.Substring(0, 220);
                cur = new Section { Level = level, Trail = trail, Own = title };
                sections.Add(cur);
            }
            else cur.Body.AppendLine(line);
        }

        var result = new List<ChunkPiece>();
        string? pendTrail = null;
        var pend = new StringBuilder();

        void Flush()
        {
            if (pendTrail != null && pend.ToString().Trim().Length > 0)
                Emit(result, pendTrail, pend.ToString().Trim());
            pendTrail = null;
            pend.Clear();
        }

        foreach (var s in sections)
        {
            string body = s.Body.ToString().Trim();
            if (body.Length == 0) continue;
            // Маленькие разделы склеиваем с предыдущим, сохраняя их заголовок внутри текста.
            if (pendTrail != null && body.Length < 250 && pend.Length + body.Length + 60 < MaxChars)
            {
                if (s.Own.Length > 0) pend.Append("\n\n").Append(new string('#', Math.Max(1, s.Level))).Append(' ').Append(s.Own).Append('\n');
                else pend.Append("\n\n");
                pend.Append(body);
                continue;
            }
            Flush();
            pendTrail = s.Trail;
            pend.Append(body);
        }
        Flush();
        return result;
    }

    static void Emit(List<ChunkPiece> res, string trail, string body)
    {
        var paras = body.Split(new[] { "\n\n" }, StringSplitOptions.RemoveEmptyEntries)
            .Select(p => p.Trim()).Where(p => p.Length > 0).ToList();
        var buf = new StringBuilder();
        string? last = null;

        void Add()
        {
            string b = buf.ToString().Trim();
            if (b.Length > 0) res.Add(new ChunkPiece { Heading = trail, Text = trail + "\n" + b });
            buf.Clear();
        }

        foreach (string p in paras)
        {
            foreach (string piece in SplitLong(p))
            {
                if (buf.Length > 0 && buf.Length + piece.Length + 2 > MaxChars)
                {
                    Add();
                    // небольшое перекрытие: последний короткий абзац повторяем
                    if (last != null && last.Length <= 300 && !last.StartsWith("|")) buf.Append(last).Append("\n\n");
                }
                buf.Append(piece).Append("\n\n");
                last = piece;
            }
        }
        Add();
    }

    // Длинный абзац/таблица режется по строкам; у таблиц шапка повторяется в каждой части.
    static IEnumerable<string> SplitLong(string p)
    {
        int lim = MaxChars - 100;
        if (p.Length <= lim) { yield return p; yield break; }

        var lines = p.Split('\n');
        string header = "";
        int from = 0;
        if (p.StartsWith("|") && lines.Length > 2 && TableSep.IsMatch(lines[1].Trim()))
        {
            header = lines[0] + "\n" + lines[1] + "\n";
            from = 2;
        }
        var sb = new StringBuilder(header);
        for (int i = from; i < lines.Length; i++)
        {
            string l = lines[i];
            if (sb.Length > header.Length && sb.Length + l.Length + 1 > lim)
            {
                yield return sb.ToString().TrimEnd();
                sb.Clear();
                sb.Append(header);
            }
            while (l.Length > lim)
            {
                int cut = l.LastIndexOf(' ', lim - 1);
                if (cut < lim / 2) cut = lim;
                yield return l.Substring(0, cut);
                l = l.Substring(cut).TrimStart();
            }
            sb.Append(l).Append('\n');
        }
        if (sb.Length > header.Length) yield return sb.ToString().TrimEnd();
    }
}
