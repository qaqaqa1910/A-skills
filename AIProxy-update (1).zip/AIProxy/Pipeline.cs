// =====================================================================
//  Pipeline.cs — обработка чат-запроса ДО отправки в llama-server:
//    команды (/skills, /check, /fix, /export, /eva, /report, /task, /wiki) -> навыки -> контекст -> сжатие истории -> параметры
//  Принцип: всё, что можно сделать кодом, делается кодом; в модель уходит минимум токенов.
// =====================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

public sealed class AiOptions
{
    public string SkillsDir { get; set; } = @"O:\AI\Skills";
    public string ToolsDir { get; set; } = @"O:\AI\Tools";
    public int MaxAutoSkills { get; set; } = 2;        // сколько навыков подключать автоматически к одному запросу
    public int HistoryTokens { get; set; } = 3000;     // бюджет истории диалога (оценка), сверх — старые реплики отбрасываются
    public int DefaultMaxTokens { get; set; } = 1500;  // лимит ответа по умолчанию
    public int MaxTokensCap { get; set; } = 3000;      // жёсткий потолок ответа
    public double Temperature { get; set; } = 0.2;
    public int WikiTopK { get; set; } = 3;             // сколько фрагментов документов давать модели
    public int WikiMaxChars { get; set; } = 3600;      // размер контекста документов в символах
    public double WikiMinCoverage { get; set; } = 0.5; // доля слов запроса, которая должна найтись во фрагменте
    public int MaxFixIterations { get; set; } = 2;     // потолок итераций /fix
    public string PythonPath { get; set; } = "python";
    public string GitlabUrl { get; set; } = "";
    public string GitlabToken { get; set; } = "";
    public string GitlabLintProjectId { get; set; } = "";
}

public sealed class PipelineResult
{
    public string? Direct;                 // готовый ответ без модели
    public Func<Task<string>>? Slow;       // долгая операция (/fix): ответ будет позже, соединение держится keep-alive
}

public static class MsgUtil
{
    public static int LastUser(JsonArray messages)
    {
        for (int i = messages.Count - 1; i >= 0; i--)
            if (messages[i] is JsonObject m && string.Equals(m["role"]?.ToString(), "user", StringComparison.OrdinalIgnoreCase)) return i;
        return -1;
    }

    public static string GetText(JsonObject message)
    {
        JsonNode? content = message["content"];
        if (content is JsonValue v && v.TryGetValue<string>(out string? s)) return s ?? "";
        if (content is JsonArray parts)
        {
            var list = new List<string>();
            foreach (var p in parts)
                if (p is JsonObject o && string.Equals(o["type"]?.ToString(), "text", StringComparison.OrdinalIgnoreCase))
                {
                    string? t = o["text"]?.ToString();
                    if (!string.IsNullOrWhiteSpace(t)) list.Add(t);
                }
            return string.Join("\n", list);
        }
        return "";
    }

    public static void SetText(JsonObject message, string text)
    {
        if (message["content"] is JsonArray parts)
        {
            foreach (var p in parts)
                if (p is JsonObject o && string.Equals(o["type"]?.ToString(), "text", StringComparison.OrdinalIgnoreCase)) { o["text"] = text; return; }
            parts.Insert(0, new JsonObject { ["type"] = "text", ["text"] = text });
            return;
        }
        message["content"] = text;
    }

    public static bool IsSystem(JsonObject m)
    {
        string r = m["role"]?.ToString() ?? "";
        return r.Equals("system", StringComparison.OrdinalIgnoreCase) || r.Equals("developer", StringComparison.OrdinalIgnoreCase);
    }

    public static void InsertSystem(JsonArray messages, string content)
    {
        int at = 0;
        while (at < messages.Count && messages[at] is JsonObject o && IsSystem(o)) at++;
        messages.Insert(at, new JsonObject { ["role"] = "system", ["content"] = content });
    }

    public static bool IsCommand(string text, string command)
        => text.Equals(command, StringComparison.OrdinalIgnoreCase) ||
           (text.StartsWith(command, StringComparison.OrdinalIgnoreCase) && text.Length > command.Length && char.IsWhiteSpace(text[command.Length]));
}

public sealed class ChatPipeline
{
    readonly AiOptions _o;
    readonly EvaService _eva;
    readonly SkillEngine _skills;
    readonly ToolRunner _tools;

    public ChatPipeline(AiOptions o, EvaService eva, SkillEngine skills, ToolRunner tools)
    {
        _o = o; _eva = eva; _skills = skills; _tools = tools;
    }

    public async Task<PipelineResult> ProcessAsync(JsonObject json, JsonArray messages, string linkBase, CancellationToken ct)
    {
        var res = new PipelineResult();
        int ui = MsgUtil.LastUser(messages);
        if (ui < 0 || messages[ui] is not JsonObject um) return res;
        string text = MsgUtil.GetText(um).TrimStart();
        if (!string.IsNullOrWhiteSpace(_eva.PublicUrl)) linkBase = _eva.PublicUrl.TrimEnd('/');

        // 1. Управление навыками
        if (_skills.TryCommand(text, out string? skillReply)) { res.Direct = skillReply; return res; }

        // 2. Инструменты (выполняет код, не модель)
        if (_tools.TryParse(text, out string tcmd, out string targ))
        {
            if (tcmd == "/fix") res.Slow = () => _tools.FixAsync(targ, messages, ct);
            else res.Direct = await _tools.HandleAsync(tcmd, targ, messages, linkBase, ct);
            return res;
        }

        // 3. Режим запроса
        var forced = new List<string>();
        if (SkillEngine.TryUse(text, out var useIds, out string useRest)) { forced.AddRange(useIds); text = useRest; }

        bool auto = true;
        string question = text;
        string? dataContext = null;

        if (_eva.TryParseCommand(text, out string ecmd, out string earg))
        {
            EvaOutcome o = await _eva.HandleAsync(ecmd, earg, linkBase, ct);
            if (o.Direct != null) { res.Direct = o.Direct; return res; }
            question = o.Question ?? earg;
            dataContext = o.Context;
        }
        else if (MsgUtil.IsCommand(text, "/wiki"))
        {
            question = text.Substring(5).Trim();
            if (question.Length == 0) { res.Direct = "После /wiki укажите вопрос по документации."; return res; }

            FindResult fr;
            try { fr = Knowledge.Search(question, new[] { _eva.FileIndexFile, _eva.IndexFile }, _o.WikiTopK, _o.WikiMinCoverage); }
            catch (Exception ex) { Console.Error.WriteLine("[Wiki] " + ex.Message); res.Direct = "⚠ Ошибка поиска по документам: " + ex.Message; return res; }

            Console.WriteLine("[Wiki] «" + Short(question, 120) + "» -> уверенно: " + fr.Confident + ", фрагментов: " + fr.Chunks.Count);
            if (!fr.Confident) { res.Direct = Knowledge.NotFoundText(question, fr); return res; }   // модель не вызываем — нечему «додумывать»

            forced.Add("rag-strict");
            auto = false;   // в режиме документов дополнительные навыки по словам не подключаем
            dataContext = (fr.Ambiguous ? "NOTE: several different documents match about equally. Answer separately per document and name each one; do not merge them.\n" : "")
                          + "SOURCES:" + Knowledge.BuildContext(fr.Chunks, _o.WikiMaxChars);
        }
        else if (MsgUtil.IsCommand(text, "/normal"))
        {
            question = text.Substring(7).Trim();
            if (question.Length == 0) { res.Direct = "После /normal укажите запрос."; return res; }
        }

        MsgUtil.SetText(um, question);

        // 4. Навыки: стабильный блок первым (кэш префикса), затем динамический контекст
        var sel = _skills.Select(question, forced, auto);
        if (sel.Block.Length > 0) MsgUtil.InsertSystem(messages, sel.Block);
        if (dataContext != null) MsgUtil.InsertSystem(messages, dataContext);
        Console.WriteLine("[Skills] " + string.Join(",", sel.Ids));

        // 5. Сжатие истории и параметры генерации
        TrimHistory(messages);
        ApplyParams(json, sel);
        return res;
    }

    // Оценка токенов: для русско-английского текста около 2.8 символа на токен
    static int Est(JsonObject m) => MsgUtil.GetText(m).Length * 10 / 28 + 8;

    void TrimHistory(JsonArray messages)
    {
        int Total() => messages.OfType<JsonObject>().Where(m => !MsgUtil.IsSystem(m)).Sum(Est);
        if (Total() <= _o.HistoryTokens) return;
        // Режем «пачкой» до 60% бюджета, чтобы начало промпта оставалось стабильным несколько ходов (кэш llama-server)
        int target = _o.HistoryTokens * 6 / 10;
        int removed = 0;
        while (Total() > target)
        {
            int idx = -1;
            for (int i = 0; i < messages.Count; i++)
                if (messages[i] is JsonObject m && !MsgUtil.IsSystem(m)) { idx = i; break; }
            if (idx < 0 || idx == MsgUtil.LastUser(messages)) break;
            messages.RemoveAt(idx); removed++;
        }
        // диалог должен начинаться с реплики пользователя
        while (true)
        {
            int idx = -1;
            for (int i = 0; i < messages.Count; i++)
                if (messages[i] is JsonObject m && !MsgUtil.IsSystem(m)) { idx = i; break; }
            if (idx >= 0 && messages[idx] is JsonObject f && string.Equals(f["role"]?.ToString(), "assistant", StringComparison.OrdinalIgnoreCase)) { messages.RemoveAt(idx); removed++; }
            else break;
        }
        if (removed > 0) Console.WriteLine("[Context] отброшено старых реплик: " + removed);
    }

    void ApplyParams(JsonObject json, SkillSelection sel)
    {
        json["cache_prompt"] = true;
        json["temperature"] = sel.Temperature ?? _o.Temperature;
        if (json["top_p"] == null) json["top_p"] = 0.9;
        if (json["repeat_penalty"] == null) json["repeat_penalty"] = 1.05;
        int cap = sel.MaxTokens ?? _o.DefaultMaxTokens;
        int requested = int.TryParse(json["max_tokens"]?.ToString(), out int r) ? r : 0;
        json["max_tokens"] = requested <= 0 ? cap : Math.Min(requested, _o.MaxTokensCap);
    }

    static string Short(string s, int max) => s.Length <= max ? s : s.Substring(0, max) + "...";
}
