// =====================================================================
//  DocExport.cs — экспорт Markdown в docx / xlsx / html / csv без сторонних библиотек.
//  Поддержка: заголовки, абзацы, списки, таблицы, блоки кода, **жирный**, `код`, ссылки.
//  PDF: открыть html-файл в браузере и «Печать -> Сохранить как PDF».
// =====================================================================
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;

public static class DocExport
{
    public sealed class Block
    {
        public string Kind = "p";            // h, p, li, code, table
        public int Level;                    // уровень заголовка / вложенность списка
        public string Text = "";
        public bool Ordered;
        public List<string[]> Rows = new List<string[]>();
    }

    static readonly Regex Heading = new Regex(@"^(#{1,6})\s+(.*?)\s*#*\s*$", RegexOptions.Compiled);
    static readonly Regex ListItem = new Regex(@"^(\s*)([-*+]|\d+[.)])\s+(.*)$", RegexOptions.Compiled);
    static readonly Regex Sep = new Regex(@"^\|?[\s:\-|]+\|?$", RegexOptions.Compiled);

    // ------------------------------------------------------------ разбор Markdown
    public static List<Block> Parse(string md)
    {
        var blocks = new List<Block>();
        var lines = md.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        var para = new StringBuilder();
        void FlushPara()
        {
            if (para.Length > 0) { blocks.Add(new Block { Kind = "p", Text = para.ToString().Trim() }); para.Clear(); }
        }

        for (int i = 0; i < lines.Length; i++)
        {
            string line = lines[i];
            string t = line.Trim();
            if (t.StartsWith("```"))
            {
                FlushPara();
                var code = new StringBuilder();
                i++;
                while (i < lines.Length && !lines[i].Trim().StartsWith("```")) { code.AppendLine(lines[i]); i++; }
                blocks.Add(new Block { Kind = "code", Text = code.ToString().TrimEnd() });
                continue;
            }
            if (t.Length == 0) { FlushPara(); continue; }
            var h = Heading.Match(t);
            if (h.Success) { FlushPara(); blocks.Add(new Block { Kind = "h", Level = h.Groups[1].Length, Text = h.Groups[2].Value }); continue; }
            if (t.StartsWith("|"))
            {
                FlushPara();
                var tb = new Block { Kind = "table" };
                while (i < lines.Length && lines[i].Trim().StartsWith("|"))
                {
                    string row = lines[i].Trim();
                    if (!Sep.IsMatch(row) || !row.Contains('-'))
                    {
                        var cells = row.Trim('|').Split('|').Select(c => c.Trim().Replace("\\|", "|")).ToArray();
                        tb.Rows.Add(cells);
                    }
                    i++;
                }
                i--;
                blocks.Add(tb);
                continue;
            }
            var li = ListItem.Match(line);
            if (li.Success)
            {
                FlushPara();
                blocks.Add(new Block { Kind = "li", Level = li.Groups[1].Length / 2, Ordered = char.IsDigit(li.Groups[2].Value[0]), Text = li.Groups[3].Value });
                continue;
            }
            if (para.Length > 0) para.Append(' ');
            para.Append(t);
        }
        FlushPara();
        return blocks;
    }

    public static string Title(List<Block> blocks)
        => blocks.FirstOrDefault(b => b.Kind == "h")?.Text ?? "Документ";

    // ------------------------------------------------------------ HTML
    static string Inline(string s)
    {
        s = WebUtility.HtmlEncode(s);
        s = Regex.Replace(s, @"\[([^\]]+)\]\((https?://[^)\s]+)\)", "<a href=\"$2\">$1</a>");
        s = Regex.Replace(s, @"\*\*([^*]+)\*\*", "<b>$1</b>");
        s = Regex.Replace(s, @"`([^`]+)`", "<code>$1</code>");
        return s;
    }

    public static string ToHtml(List<Block> blocks)
    {
        var sb = new StringBuilder();
        sb.Append("<!DOCTYPE html><html lang=\"ru\"><head><meta charset=\"utf-8\"><title>").Append(WebUtility.HtmlEncode(Title(blocks))).Append("</title><style>");
        sb.Append("body{font-family:Calibri,Arial,sans-serif;max-width:900px;margin:2em auto;padding:0 1em;line-height:1.5;color:#222}");
        sb.Append("table{border-collapse:collapse;margin:1em 0}td,th{border:1px solid #999;padding:4px 8px;vertical-align:top}th{background:#eee}");
        sb.Append("pre{background:#f4f4f4;padding:.8em;overflow:auto;white-space:pre-wrap}code{font-family:Consolas,monospace;background:#f4f4f4}");
        sb.Append("@media print{body{margin:0;max-width:none}}</style></head><body>");
        string? list = null;
        void CloseList() { if (list != null) { sb.Append("</").Append(list).Append('>'); list = null; } }
        foreach (var b in blocks)
        {
            if (b.Kind != "li") CloseList();
            switch (b.Kind)
            {
                case "h": sb.Append("<h").Append(b.Level).Append('>').Append(Inline(b.Text)).Append("</h").Append(b.Level).Append('>'); break;
                case "p": sb.Append("<p>").Append(Inline(b.Text)).Append("</p>"); break;
                case "code": sb.Append("<pre>").Append(WebUtility.HtmlEncode(b.Text)).Append("</pre>"); break;
                case "li":
                    string tag = b.Ordered ? "ol" : "ul";
                    if (list != tag) { CloseList(); sb.Append('<').Append(tag).Append('>'); list = tag; }
                    sb.Append("<li>").Append(Inline(b.Text)).Append("</li>");
                    break;
                case "table":
                    sb.Append("<table>");
                    for (int r = 0; r < b.Rows.Count; r++)
                    {
                        sb.Append("<tr>");
                        foreach (string c in b.Rows[r]) sb.Append(r == 0 ? "<th>" : "<td>").Append(Inline(c)).Append(r == 0 ? "</th>" : "</td>");
                        sb.Append("</tr>");
                    }
                    sb.Append("</table>");
                    break;
            }
        }
        CloseList();
        sb.Append("</body></html>");
        return sb.ToString();
    }

    // ------------------------------------------------------------ CSV (первая таблица)
    public static string? ToCsv(List<Block> blocks)
    {
        var t = blocks.FirstOrDefault(b => b.Kind == "table");
        if (t == null) return null;
        return string.Join("\r\n", t.Rows.Select(r => string.Join(";", r.Select(c => "\"" + c.Replace("\"", "\"\"") + "\""))));
    }

    // ------------------------------------------------------------ DOCX
    static string X(string s)
    {
        var clean = new string((s ?? "").Where(ch => ch == '\t' || ch == '\n' || ch == '\r' || ch >= ' ').ToArray());
        return SecurityElement.Escape(clean) ?? "";
    }

    static string Runs(string text, string extraRpr = "")
    {
        var sb = new StringBuilder();
        text = Regex.Replace(text, @"\[([^\]]+)\]\((https?://[^)\s]+)\)", "$1 ($2)");
        foreach (string part in Regex.Split(text, @"(\*\*[^*]+\*\*|`[^`]+`)"))
        {
            if (part.Length == 0) continue;
            string rpr = extraRpr, val = part;
            if (part.StartsWith("**") && part.EndsWith("**") && part.Length > 4) { rpr += "<w:b/>"; val = part.Substring(2, part.Length - 4); }
            else if (part.StartsWith("`") && part.EndsWith("`") && part.Length > 2) { rpr += "<w:rFonts w:ascii=\"Consolas\" w:hAnsi=\"Consolas\"/>"; val = part.Substring(1, part.Length - 2); }
            sb.Append("<w:r>").Append(rpr.Length > 0 ? "<w:rPr>" + rpr + "</w:rPr>" : "").Append("<w:t xml:space=\"preserve\">").Append(X(val)).Append("</w:t></w:r>");
        }
        return sb.ToString();
    }

    public static byte[] ToDocx(List<Block> blocks)
    {
        var body = new StringBuilder();
        int num = 0;
        foreach (var b in blocks)
        {
            if (b.Kind != "li") num = 0;
            switch (b.Kind)
            {
                case "h":
                    body.Append("<w:p><w:pPr><w:pStyle w:val=\"Heading").Append(Math.Min(b.Level, 6)).Append("\"/></w:pPr>").Append(Runs(b.Text)).Append("</w:p>");
                    break;
                case "p":
                    body.Append("<w:p>").Append(Runs(b.Text)).Append("</w:p>");
                    break;
                case "li":
                    string mark = b.Ordered ? (++num) + ". " : "• ";
                    body.Append("<w:p><w:pPr><w:ind w:left=\"").Append(720 + 360 * b.Level).Append("\" w:hanging=\"360\"/></w:pPr><w:r><w:t xml:space=\"preserve\">")
                        .Append(X(mark)).Append("</w:t></w:r>").Append(Runs(b.Text)).Append("</w:p>");
                    break;
                case "code":
                    foreach (string l in b.Text.Split('\n'))
                        body.Append("<w:p><w:pPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"F2F2F2\"/><w:spacing w:after=\"0\"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii=\"Consolas\" w:hAnsi=\"Consolas\" w:cs=\"Consolas\"/><w:sz w:val=\"18\"/></w:rPr><w:t xml:space=\"preserve\">")
                            .Append(X(l.TrimEnd('\r'))).Append("</w:t></w:r></w:p>");
                    body.Append("<w:p/>");
                    break;
                case "table":
                    int cols = Math.Max(1, b.Rows.Max(r => r.Length));
                    int w = 9000 / cols;
                    body.Append("<w:tbl><w:tblPr><w:tblW w:w=\"5000\" w:type=\"pct\"/><w:tblBorders>");
                    foreach (string side in new[] { "top", "left", "bottom", "right", "insideH", "insideV" })
                        body.Append("<w:").Append(side).Append(" w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>");
                    body.Append("</w:tblBorders></w:tblPr><w:tblGrid>");
                    for (int c = 0; c < cols; c++) body.Append("<w:gridCol w:w=\"").Append(w).Append("\"/>");
                    body.Append("</w:tblGrid>");
                    for (int r = 0; r < b.Rows.Count; r++)
                    {
                        body.Append("<w:tr>");
                        for (int c = 0; c < cols; c++)
                        {
                            string cell = c < b.Rows[r].Length ? b.Rows[r][c] : "";
                            body.Append("<w:tc><w:tcPr><w:tcW w:w=\"").Append(w).Append("\" w:type=\"dxa\"/>");
                            if (r == 0) body.Append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"E7E6E6\"/>");
                            body.Append("</w:tcPr><w:p>").Append(Runs(cell, r == 0 ? "<w:b/>" : "")).Append("</w:p></w:tc>");
                        }
                        body.Append("</w:tr>");
                    }
                    body.Append("</w:tbl><w:p/>");
                    break;
            }
        }
        string W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"";
        string doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document " + W + "><w:body>" + body +
                     "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1134\" w:right=\"850\" w:bottom=\"1134\" w:left=\"1701\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>";

        var styles = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:styles " + W + ">");
        styles.Append("<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:cs=\"Calibri\" w:eastAsia=\"Calibri\"/><w:sz w:val=\"22\"/><w:lang w:val=\"ru-RU\"/></w:rPr></w:rPrDefault>");
        styles.Append("<w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"264\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>");
        styles.Append("<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style>");
        int[] sizes = { 36, 30, 26, 24, 22, 22 };
        for (int i = 1; i <= 6; i++)
            styles.Append("<w:style w:type=\"paragraph\" w:styleId=\"Heading" + i + "\"><w:name w:val=\"heading " + i + "\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/>" +
                          "<w:pPr><w:keepNext/><w:spacing w:before=\"240\" w:after=\"80\"/><w:outlineLvl w:val=\"" + (i - 1) + "\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"" + sizes[i - 1] + "\"/></w:rPr></w:style>");
        styles.Append("</w:styles>");

        using var ms = new MemoryStream();
        using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
        {
            Add(zip, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/><Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/></Types>");
            Add(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
            Add(zip, "word/_rels/document.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            Add(zip, "word/document.xml", doc);
            Add(zip, "word/styles.xml", styles.ToString());
        }
        return ms.ToArray();
    }

    // ------------------------------------------------------------ XLSX (каждая таблица — отдельный лист)
    static string Col(int i)
    {
        string s = "";
        for (i++; i > 0; i = (i - 1) / 26) s = (char)('A' + (i - 1) % 26) + s;
        return s;
    }

    public static byte[] ToXlsx(List<Block> blocks)
    {
        var sheets = new List<(string name, List<string[]> rows)>();
        foreach (var b in blocks.Where(x => x.Kind == "table"))
            sheets.Add(("Таблица " + (sheets.Count + 1), b.Rows));
        if (sheets.Count == 0)
            sheets.Add(("Текст", blocks.SelectMany(b => b.Kind == "code" ? b.Text.Split('\n') : new[] { b.Text }).Select(l => new[] { l }).ToList()));

        string NS = "xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"";
        using var ms = new MemoryStream();
        using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
        {
            var ct = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            var wb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook " + NS + " xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
            var rels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");

            for (int s = 0; s < sheets.Count; s++)
            {
                var (name, rows) = sheets[s];
                int cols = Math.Max(1, rows.Count == 0 ? 1 : rows.Max(r => r.Length));
                var sh = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet " + NS + ">");
                sh.Append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>");
                for (int c = 0; c < cols; c++)
                {
                    int len = rows.Take(200).Select(r => c < r.Length ? r[c].Length : 0).DefaultIfEmpty(8).Max();
                    sh.Append("<col min=\"").Append(c + 1).Append("\" max=\"").Append(c + 1).Append("\" width=\"").Append(Math.Min(60, Math.Max(8, len + 2))).Append("\" customWidth=\"1\"/>");
                }
                sh.Append("</cols><sheetData>");
                for (int r = 0; r < rows.Count; r++)
                {
                    sh.Append("<row r=\"").Append(r + 1).Append("\">");
                    for (int c = 0; c < rows[r].Length; c++)
                    {
                        string v = rows[r][c], cell = Col(c) + (r + 1);
                        string style = r == 0 && sheets[s].name != "Текст" ? " s=\"1\"" : "";
                        bool numeric = r > 0 && v.Length > 0 && v.Length < 15 && !(v.Length > 1 && v[0] == '0' && v[1] != '.' && v[1] != ',')
                                       && double.TryParse(v.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out _);
                        if (numeric) sh.Append("<c r=\"").Append(cell).Append('"').Append(style).Append("><v>").Append(v.Replace(',', '.')).Append("</v></c>");
                        else sh.Append("<c r=\"").Append(cell).Append("\" t=\"inlineStr\"").Append(style).Append("><is><t xml:space=\"preserve\">").Append(X(v)).Append("</t></is></c>");
                    }
                    sh.Append("</row>");
                }
                sh.Append("</sheetData>");
                if (rows.Count > 1) sh.Append("<autoFilter ref=\"A1:").Append(Col(cols - 1)).Append(rows.Count).Append("\"/>");
                sh.Append("</worksheet>");
                Add(zip, "xl/worksheets/sheet" + (s + 1) + ".xml", sh.ToString());

                string safe = Regex.Replace(name, @"[\\/?*\[\]:]", "_");
                if (safe.Length > 31) safe = safe.Substring(0, 31);
                ct.Append("<Override PartName=\"/xl/worksheets/sheet").Append(s + 1).Append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
                wb.Append("<sheet name=\"").Append(X(safe)).Append("\" sheetId=\"").Append(s + 1).Append("\" r:id=\"rId").Append(s + 1).Append("\"/>");
                rels.Append("<Relationship Id=\"rId").Append(s + 1).Append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").Append(s + 1).Append(".xml\"/>");
            }
            rels.Append("<Relationship Id=\"rId").Append(sheets.Count + 1).Append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            ct.Append("</Types>");
            wb.Append("</sheets></workbook>");

            Add(zip, "[Content_Types].xml", ct.ToString());
            Add(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            Add(zip, "xl/workbook.xml", wb.ToString());
            Add(zip, "xl/_rels/workbook.xml.rels", rels.ToString());
            Add(zip, "xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet " + NS + "><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs></styleSheet>");
        }
        return ms.ToArray();
    }

    static void Add(ZipArchive zip, string name, string content)
    {
        var e = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var s = e.Open();
        byte[] b = new UTF8Encoding(false).GetBytes(content);
        s.Write(b, 0, b.Length);
    }
}
